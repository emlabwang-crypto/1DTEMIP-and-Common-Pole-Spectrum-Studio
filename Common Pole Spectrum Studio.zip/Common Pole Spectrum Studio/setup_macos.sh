#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
command -v gfortran >/dev/null || { echo "gfortran is required."; exit 1; }
if command -v python3.12 >/dev/null 2>&1; then
  PYTHON=python3.12
else
  PYTHON=python3
fi
"$PYTHON" -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
mkdir -p bin
rm -f bin/libfig2_core.dylib
gfortran -O3 -fPIC -dynamiclib -Wl,-exported_symbol,_ip_eval -o bin/libfig2_core.dylib src/constitutive.f90
.venv/bin/python -m studio.check_native
.venv/bin/python -m unittest discover -s tests
