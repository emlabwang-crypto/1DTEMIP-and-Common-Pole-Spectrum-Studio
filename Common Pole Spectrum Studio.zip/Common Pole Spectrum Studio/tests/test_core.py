import tempfile
import unittest
from pathlib import Path

import numpy as np

from studio.core import Native, Parameters, export_data, optimize
from studio.themes import PALETTES, stylesheet


class ConstitutiveTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.result = optimize(Parameters())

    def test_defaults(self):
        result = self.result
        self.assertEqual(len(result.poles), 68)
        self.assertTrue(result.validated)
        self.assertTrue(np.all(result.weights >= 0))
        np.testing.assert_allclose(result.weights.sum(axis=1), 1, atol=1e-12)
        self.assertGreater(result.accepted_moves, 0)

    def test_fixed_rates(self):
        r = self.result
        for k, rate in enumerate(r.exact_rates):
            j = np.argmin(abs(r.poles - rate))
            self.assertAlmostEqual(r.poles[j], rate, delta=rate * 1e-12)
        self.assertEqual(np.count_nonzero(r.weights[0]), 1)
        self.assertEqual(np.count_nonzero(r.weights[3]), 3)

    def test_parameter_change(self):
        changed = optimize(Parameters(chargeability=0.25, poles=48,
                                      fit_samples=128, check_samples=256,
                                      refine_sweeps=1))
        self.assertEqual(len(changed.poles), 48)
        self.assertNotAlmostEqual(changed.exact_rates[0], self.result.exact_rates[0])

    def test_export(self):
        with tempfile.TemporaryDirectory() as d:
            export_data(self.result, d)
            for name in ("pole_weights.csv", "phase_spectra.csv", "fit_summary.json"):
                self.assertTrue((Path(d) / name).is_file())

    def test_light_themes(self):
        self.assertEqual(len(PALETTES), 5)
        for name in PALETTES:
            self.assertTrue("light" in name.lower() or "quiet" in name.lower())
            self.assertIn("QMainWindow", stylesheet(name, 12))


if __name__ == "__main__":
    unittest.main()
