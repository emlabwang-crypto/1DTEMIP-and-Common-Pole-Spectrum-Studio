module fig2_constitutive
  use, intrinsic :: iso_c_binding, only: c_int, c_double
  implicit none
  private
  public :: ip_eval
contains
  pure real(c_double) function high_sigma(sigma_b, g0, volume, inclusion) result(value)
    real(c_double), intent(in) :: sigma_b, g0, volume(3), inclusion(3)
    integer :: j
    value = sigma_b*g0
    do j = 1, 3
      value = value + 9.0_c_double*volume(j)*sigma_b*inclusion(j) / &
        (4.0_c_double*sigma_b + 2.0_c_double*inclusion(j))
    end do
  end function high_sigma

  subroutine ip_eval(n, sr, si, par, fr, fi, sig_r, sig_i, rates, exact_w, status) &
      bind(C, name='ip_eval')
    integer(c_int), value, intent(in) :: n
    real(c_double), intent(in) :: sr(n), si(n), par(22)
    real(c_double), intent(out) :: fr(4,n), fi(4,n), sig_r(4,n), sig_i(4,n)
    real(c_double), intent(out) :: rates(4), exact_w(4)
    integer(c_int), intent(out) :: status
    real(c_double) :: sigma_inf, m, tau_rho, cc_exp, vg(2), tg(2), cg(2)
    real(c_double) :: vm(3), sm(3), rm(3), lm(3), g0, sigma_b
    real(c_double) :: lo, hi, mid, target, taum(3), eta(3), etasum
    real(c_double) :: sigma0(4)
    complex(c_double) :: s, z, f(4), h
    integer :: j, k

    fr = 0.0_c_double; fi = 0.0_c_double
    sig_r = 0.0_c_double; sig_i = 0.0_c_double
    rates = 0.0_c_double; exact_w = 0.0_c_double
    status = 1
    if (n <= 0) return
    sigma_inf = par(1); m = par(2); tau_rho = par(3); cc_exp = par(4)
    vg = par(5:6); tg = par(7:8); cg = par(9:10)
    vm = par(11:13); sm = par(14:16)
    rm = par(17:19); lm = par(20:22)
    if (sigma_inf <= 0.0_c_double) return
    if (m <= 0.0_c_double .or. m >= 1.0_c_double .or. tau_rho <= 0.0_c_double) return
    if (cc_exp <= 0.0_c_double .or. cc_exp > 1.0_c_double) return
    if (any(vg <= 0.0_c_double) .or. sum(vg) >= 1.0_c_double) return
    if (any(tg <= 0.0_c_double) .or. any(cg <= 0.0_c_double) .or. any(cg > 1.0_c_double)) return
    if (any(vm <= 0.0_c_double) .or. sum(vm) >= 2.0_c_double/3.0_c_double) return
    if (any(sm <= 0.0_c_double) .or. any(rm <= 0.0_c_double) .or. any(lm <= 0.0_c_double)) return
    status = 2
    g0 = 1.0_c_double - 1.5_c_double*sum(vm)
    target = sigma_inf
    lo = 0.0_c_double
    hi = max(target/g0, target)
    do j = 1, 100
      if (high_sigma(hi, g0, vm, sm) >= target) exit
      hi = 2.0_c_double*hi
    end do
    if (high_sigma(hi, g0, vm, sm) < target) return
    do j = 1, 160
      mid = 0.5_c_double*(lo+hi)
      if (high_sigma(mid, g0, vm, sm) < target) then
        lo = mid
      else
        hi = mid
      end if
    end do
    sigma_b = 0.5_c_double*(lo+hi)
    taum = rm*lm*(2.0_c_double*sigma_b+sm)/(2.0_c_double*sigma_b*sm)
    eta = 9.0_c_double*vm*sm/((4.0_c_double*sigma_b+2.0_c_double*sm)*g0)
    etasum = sum(eta)
    if (etasum <= 0.0_c_double) return
    rates(1) = 1.0_c_double / ((1.0_c_double-m)*tau_rho)
    rates(2:4) = 1.0_c_double/taum
    exact_w(1) = 1.0_c_double
    exact_w(2:4) = eta/etasum
    sigma0(1:2) = (1.0_c_double-m)*sigma_inf
    sigma0(3) = sigma_inf/(1.0_c_double+3.0_c_double*sum(vg))
    sigma0(4) = sigma_b*g0
    do j = 1, n
      s = cmplx(sr(j),si(j),kind=c_double)
      z = (1.0_c_double-m)*(s*tau_rho)
      f(1) = z/(1.0_c_double+z)
      z = (1.0_c_double-m)*(s*tau_rho)**cc_exp
      f(2) = z/(1.0_c_double+z)
      f(3) = cmplx(0.0_c_double,0.0_c_double,kind=c_double)
      do k = 1,2
        z = (s*tg(k))**cg(k)
        h = z/(1.0_c_double+z)
        f(3) = f(3)+vg(k)*h/sum(vg)
      end do
      f(4) = cmplx(0.0_c_double,0.0_c_double,kind=c_double)
      do k = 1,3
        z = s*taum(k)
        f(4) = f(4)+(eta(k)/etasum)*(z/(1.0_c_double+z))
      end do
      do k = 1,4
        fr(k,j) = real(f(k),kind=c_double)
        fi(k,j) = aimag(f(k))
        z = sigma0(k)+(sigma_inf-sigma0(k))*f(k)
        sig_r(k,j) = real(z,kind=c_double)
        sig_i(k,j) = aimag(z)
      end do
    end do
    status = 0
  end subroutine ip_eval
end module fig2_constitutive
