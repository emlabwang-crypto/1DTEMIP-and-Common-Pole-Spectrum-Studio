#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
.venv/bin/python -m studio.check_native
exec .venv/bin/python -m studio.gui
