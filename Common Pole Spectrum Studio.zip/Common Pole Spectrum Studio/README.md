# Common Pole Spectrum Studio

Light themes only: Light Modern, Light+, Solarized Light, Quiet Light, and High Contrast Light.

The Fortran library evaluates Debye, Cole-Cole, GEMTIP, and MGEMTIP constitutive functions. Python computes common pole positions with nonlinear refinement and nonnegative variable-projection fits. Debye and MGEMTIP analytical poles remain fixed. The three plots show resistivity phase, analytical weights, and distributed spectral weights. Default values follow the paper's Table I benchmark.

## macOS

Install Python 3.12 and `gfortran` (Homebrew is supported). In Terminal:

```bash
bash setup_macos.sh
bash run_macos.sh
```

## Windows

Install Python 3.12 or later and MinGW-w64 `gfortran` via MSYS2. Add the compiler's `bin` directory to PATH. In Command Prompt:

```bat
setup_windows.bat
run_windows.bat
```

The setup scripts always rebuild the native library and verify its exported `ip_eval` symbol by loading it through Python. If the library fails to load, check the architecture of Python and gfortran, and rerun setup.

Exported files: `phase_spectra.csv`, `pole_weights.csv`, `fit_summary.json`, PNG, and SVG. Errors refer to the normalized constitutive response, not the three-dimensional field response.
