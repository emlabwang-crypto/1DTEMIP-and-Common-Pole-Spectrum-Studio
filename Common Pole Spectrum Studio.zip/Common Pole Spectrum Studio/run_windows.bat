@echo off
cd /d "%~dp0"
.venv\Scripts\python.exe -m studio.check_native || exit /b 1
.venv\Scripts\python.exe -m studio.gui
