@echo off
setlocal
cd /d "%~dp0"
where gfortran >nul 2>&1 || (echo gfortran is required. & exit /b 1)
py -3 -m venv .venv || exit /b 1
.venv\Scripts\python.exe -m pip install -r requirements.txt || exit /b 1
if not exist bin mkdir bin
if exist bin\fig2_core.dll del /q bin\fig2_core.dll
gfortran -O3 -shared -o bin\fig2_core.dll src\constitutive.f90 || exit /b 1
.venv\Scripts\python.exe -m studio.check_native || exit /b 1
.venv\Scripts\python.exe -m unittest discover -s tests || exit /b 1
