"""Light themed constitutive spectrum desktop application."""
from __future__ import annotations

import sys

import numpy as np
from PySide6.QtCore import QThread, Qt, Signal, QTimer
from PySide6.QtGui import QDoubleValidator, QFont
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QFileDialog, QFormLayout, QFrame,
    QHBoxLayout, QLabel, QLineEdit, QMainWindow, QMessageBox, QPushButton,
    QScrollArea, QSpinBox, QSplitter, QTabWidget, QVBoxLayout, QWidget,
)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure
from matplotlib.ticker import LogLocator

from .core import MODELS, Parameters, export_data, optimize
from .themes import PALETTES, stylesheet

COLORS = ("#d76f0b", "#0b65c2", "#b8198c", "#794bb1")
FIELDS = {
    "Constitutive": (
        ("sigma_inf", "Unrelaxed conductivity (S/m)"),
        ("chargeability", "Chargeability m"),
        ("tau_rho", "Debye / Cole time (s)"),
        ("cole_c", "Cole-Cole exponent c"),
    ),
    "GEMTIP": (
        ("gem_v1", "Volume fraction 1"), ("gem_v2", "Volume fraction 2"),
        ("gem_tau1", "Relaxation time 1 (s)"), ("gem_tau2", "Relaxation time 2 (s)"),
        ("gem_c1", "Exponent 1"), ("gem_c2", "Exponent 2"),
    ),
    "MGEMTIP": (
        ("mg_v1", "Volume fraction 1"), ("mg_v2", "Volume fraction 2"),
        ("mg_v3", "Volume fraction 3"),
        ("mg_sigma1", "Inclusion sigma 1 (S/m)"),
        ("mg_sigma2", "Inclusion sigma 2 (S/m)"),
        ("mg_sigma3", "Inclusion sigma 3 (S/m)"),
        ("mg_radius1", "Radius 1 (m)"), ("mg_radius2", "Radius 2 (m)"),
        ("mg_radius3", "Radius 3 (m)"),
        ("mg_lambda1", "Lambda 1 (F/m²)"),
        ("mg_lambda2", "Lambda 2 (F/m²)"),
        ("mg_lambda3", "Lambda 3 (F/m²)"),
    ),
    "Optimization": (
        ("tolerance", "Maximum normalized error"),
        ("fit_min", "Minimum Laplace rate (1/s)"),
        ("fit_max", "Maximum Laplace rate (1/s)"),
        ("rate_min", "Minimum pole rate (1/s)"),
        ("rate_max", "Maximum pole rate (1/s)"),
    ),
}


class FitThread(QThread):
    completed = Signal(object)
    failed = Signal(str)
    progress = Signal(str)

    def __init__(self, parameters: Parameters):
        super().__init__()
        self.parameters = parameters

    def run(self):
        try:
            self.completed.emit(optimize(self.parameters, self.progress.emit))
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class SpectraCanvas(FigureCanvasQTAgg):
    def __init__(self, parent=None):
        self.figure = Figure(figsize=(12, 7), dpi=105)
        super().__init__(self.figure)
        self.setParent(parent)

    def plot(self, data, theme: str, font_size: int):
        bg, panel, input_bg, fg, accent, border = PALETTES[theme]
        self.figure.clear()
        self.figure.set_facecolor(bg)
        grid = self.figure.add_gridspec(2, 2, width_ratios=(1.04, 1),
                                         hspace=0.41, wspace=0.31,
                                         left=0.10, right=0.965, bottom=0.14, top=0.92)
        a = self.figure.add_subplot(grid[:, 0])
        b = self.figure.add_subplot(grid[0, 1])
        c = self.figure.add_subplot(grid[1, 1])
        for ax in (a, b, c):
            ax.set_facecolor(bg)
            ax.tick_params(which="both", colors=fg, labelsize=max(9, font_size-2))
            ax.grid(which="major", color=border, alpha=0.7, linewidth=0.65)
            ax.set_xscale("log")
            ax.xaxis.set_major_locator(LogLocator(base=10, numticks=7))
            for spine in ax.spines.values():
                spine.set_color(border)
            ax.title.set_color(fg)
            ax.xaxis.label.set_color(fg)
            ax.yaxis.label.set_color(fg)
        for i, name in enumerate(MODELS):
            a.plot(data.frequency, data.phases[i], color=COLORS[i], linewidth=2, label=name)
        a.set_title("(a) Complex resistivity phase", fontsize=font_size+1)
        a.set_xlabel("Frequency (Hz)", fontsize=font_size)
        a.set_ylabel("|Resistivity phase| (mrad)", fontsize=font_size)
        a.set_xlim(data.frequency[0], data.frequency[-1])
        a.set_ylim(bottom=0)
        self._legend(a, font_size, fg)
        for i in (0, 3):
            mask = data.weights[i] > 1e-12
            b.vlines(data.poles[mask], 0, data.weights[i, mask], colors=COLORS[i], linewidth=1.6)
            b.scatter(data.poles[mask], data.weights[i, mask], s=24, color=COLORS[i], label=MODELS[i])
        b.set_title("(b) Analytical pole weights", fontsize=font_size+1)
        b.set_ylabel("Normalized weight", fontsize=font_size)
        b.set_ylim(bottom=0)
        self._legend(b, font_size, fg)
        for i in (1, 2):
            mask = data.weights[i] > 1e-9
            c.vlines(data.poles[mask], 0, data.weights[i, mask], colors=COLORS[i], linewidth=0.9)
            c.scatter(data.poles[mask], data.weights[i, mask], s=13, color=COLORS[i], label=MODELS[i])
        c.set_title("(c) Optimized distributed weights", fontsize=font_size+1)
        c.set_xlabel("Common pole rate (1/s)", fontsize=font_size)
        c.set_ylabel("Normalized weight", fontsize=font_size)
        c.set_ylim(bottom=0)
        self._legend(c, font_size, fg)
        b.set_xlim(data.params.rate_min, data.params.rate_max)
        c.set_xlim(data.params.rate_min, data.params.rate_max)
        self.draw_idle()

    @staticmethod
    def _legend(ax, size, fg):
        legend = ax.legend(frameon=False, fontsize=max(9, size-2))
        for label in legend.get_texts():
            label.set_color(fg)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Common Pole Spectrum Studio")
        self.resize(1500, 880)
        self.setMinimumSize(1000, 650)
        self.widgets = {}
        self.result = None
        self.thread = None
        self._build()
        self.apply_theme()
        QTimer.singleShot(120, self.run_fit)

    def _tab(self, fields, defaults):
        content = QWidget()
        form = QFormLayout(content)
        form.setContentsMargins(11, 14, 11, 14)
        form.setSpacing(8)
        for name, label in fields:
            widget = QLineEdit(f"{getattr(defaults, name):.9g}")
            widget.setValidator(QDoubleValidator())
            widget.setMinimumWidth(110)
            self.widgets[name] = widget
            caption = QLabel(label)
            caption.setWordWrap(True)
            form.addRow(caption, widget)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setWidget(content)
        return scroll

    def _build(self):
        base = QWidget()
        self.setCentralWidget(base)
        layout = QVBoxLayout(base)
        layout.setContentsMargins(12, 10, 12, 10)
        top = QHBoxLayout()
        title = QLabel("COMMON POLE · CONSTITUTIVE SPECTRA")
        title.setStyleSheet("font-weight:700")
        top.addWidget(title)
        top.addStretch()
        top.addWidget(QLabel("Theme"))
        self.theme = QComboBox()
        self.theme.addItems(PALETTES)
        self.theme.currentTextChanged.connect(self.apply_theme)
        top.addWidget(self.theme)
        top.addWidget(QLabel("Font"))
        self.font_size = QSpinBox()
        self.font_size.setRange(11, 16)
        self.font_size.setValue(12)
        self.font_size.valueChanged.connect(self.apply_theme)
        top.addWidget(self.font_size)
        reset = QPushButton("Defaults")
        reset.clicked.connect(self.restore_defaults)
        top.addWidget(reset)
        self.run_button = QPushButton("Optimize and Plot")
        self.run_button.setObjectName("run")
        self.run_button.clicked.connect(self.run_fit)
        top.addWidget(self.run_button)
        layout.addLayout(top)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        layout.addWidget(splitter, 1)
        controls = QFrame()
        controls.setObjectName("panel")
        controls.setMinimumWidth(310)
        controls.setMaximumWidth(420)
        ctrl = QVBoxLayout(controls)
        ctrl.setContentsMargins(8, 9, 8, 9)
        tabs = QTabWidget()
        defaults = Parameters()
        for caption, fields in FIELDS.items():
            tabs.addTab(self._tab(fields, defaults), caption)
        ctrl.addWidget(tabs, 1)
        options = QFormLayout()
        self.pole_count = QSpinBox()
        self.pole_count.setRange(12, 160)
        self.pole_count.setValue(defaults.poles)
        options.addRow("Pole budget", self.pole_count)
        self.sweeps = QSpinBox()
        self.sweeps.setRange(0, 6)
        self.sweeps.setValue(defaults.refine_sweeps)
        options.addRow("Refinement sweeps", self.sweeps)
        self.prune = QCheckBox("Prune redundant poles")
        options.addRow(self.prune)
        ctrl.addLayout(options)
        self.progress = QLabel("Ready")
        self.progress.setWordWrap(True)
        self.progress.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        ctrl.addWidget(self.progress)
        splitter.addWidget(controls)

        panel = QWidget()
        right = QVBoxLayout(panel)
        right.setContentsMargins(0, 0, 0, 0)
        self.canvas = SpectraCanvas(panel)
        right.addWidget(self.canvas, 1)
        actions = QHBoxLayout()
        self.summary = QLabel("Table I defaults · 68 shared poles")
        self.summary.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        actions.addWidget(self.summary, 1)
        export_figure = QPushButton("Export Figure")
        export_figure.clicked.connect(self.export_figure)
        actions.addWidget(export_figure)
        export_values = QPushButton("Export Data")
        export_values.clicked.connect(self.export_values)
        actions.addWidget(export_values)
        right.addLayout(actions)
        splitter.addWidget(panel)
        splitter.setSizes([360, 1100])
        self.statusBar().showMessage("Ready")

    def apply_theme(self, *_):
        self.setStyleSheet(stylesheet(self.theme.currentText(), self.font_size.value()))
        font = QFont("Segoe UI" if sys.platform == "win32" else "Arial")
        font.setPointSize(self.font_size.value())
        QApplication.instance().setFont(font)
        if self.result is not None:
            self.canvas.plot(self.result, self.theme.currentText(), self.font_size.value())

    def restore_defaults(self):
        defaults = Parameters()
        for key, widget in self.widgets.items():
            widget.setText(f"{getattr(defaults, key):.9g}")
        self.pole_count.setValue(defaults.poles)
        self.sweeps.setValue(defaults.refine_sweeps)
        self.prune.setChecked(False)

    def _parameters(self):
        p = Parameters()
        for key, widget in self.widgets.items():
            value = widget.text().strip()
            if not value:
                raise ValueError(f"Missing parameter: {key}")
            setattr(p, key, float(value))
        p.poles = self.pole_count.value()
        p.refine_sweeps = self.sweeps.value()
        p.prune = self.prune.isChecked()
        return p

    def run_fit(self):
        if self.thread is not None and self.thread.isRunning():
            return
        try:
            params = self._parameters()
        except Exception as exc:
            QMessageBox.warning(self, "Invalid parameters", str(exc))
            return
        self.run_button.setEnabled(False)
        self.progress.setText("Optimizing shared poles...")
        self.statusBar().showMessage("Computing")
        self.thread = FitThread(params)
        self.thread.progress.connect(self.progress.setText)
        self.thread.completed.connect(self._completed)
        self.thread.failed.connect(self._failed)
        self.thread.finished.connect(self._clear_thread)
        self.thread.start()

    def _clear_thread(self):
        if self.thread is not None:
            self.thread.deleteLater()
            self.thread = None

    def _completed(self, result):
        self.result = result
        self.run_button.setEnabled(True)
        self.canvas.plot(result, self.theme.currentText(), self.font_size.value())
        message = "PASS" if result.validated else "CHECK FIT"
        self.summary.setText(
            f"{len(result.poles)} poles | fixed: 4 | refined: {result.accepted_moves} | "
            f"Cole-Cole {result.errors[1]:.2e} | GEMTIP {result.errors[2]:.2e} | {message}")
        self.statusBar().showMessage("Calculation complete")

    def _failed(self, error):
        self.run_button.setEnabled(True)
        self.progress.setText(error)
        self.statusBar().showMessage("Calculation failed")
        QMessageBox.warning(self, "Calculation error", error)

    def export_figure(self):
        if self.result is None:
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export figure", "fig02_spectra.png",
                                              "PNG (*.png);;SVG (*.svg)")
        if path:
            self.canvas.figure.savefig(path, dpi=600, facecolor=self.canvas.figure.get_facecolor())

    def export_values(self):
        if self.result is None:
            return
        path = QFileDialog.getExistingDirectory(self, "Export data")
        if path:
            export_data(self.result, path)

    def closeEvent(self, event):
        if self.thread is not None and self.thread.isRunning():
            self.thread.wait()
        event.accept()


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Common Pole Spectrum Studio")
    window = MainWindow()
    window.show()
    raise SystemExit(app.exec())


if __name__ == "__main__":
    main()
