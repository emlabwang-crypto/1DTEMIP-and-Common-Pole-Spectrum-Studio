"""Validate the exported Fortran C interface."""
import numpy as np
from .core import Native, Parameters


def main():
    native = Native()
    _, sigma, rates, weights = native.evaluate(np.asarray([1j, 10j]), Parameters())
    assert sigma.shape == (4, 2)
    assert np.isfinite(sigma).all()
    assert np.all(rates > 0)
    assert abs(weights[1:].sum() - 1) < 1e-12
    print("Fortran ip_eval interface: OK")


if __name__ == "__main__":
    main()
