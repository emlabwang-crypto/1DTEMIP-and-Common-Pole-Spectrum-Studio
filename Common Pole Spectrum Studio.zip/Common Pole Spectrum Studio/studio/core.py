"""Constitutive spectra and shared pole optimization."""
from __future__ import annotations

import ctypes
import json
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable

import numpy as np
from scipy.optimize import minimize, nnls
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parents[1]
MODELS = ("Debye", "Cole-Cole", "GEMTIP", "MGEMTIP")


@dataclass
class Parameters:
    sigma_inf: float = 0.01
    chargeability: float = 0.30
    tau_rho: float = 0.10
    cole_c: float = 0.50
    gem_v1: float = 0.05
    gem_v2: float = 0.05
    gem_tau1: float = 0.01
    gem_tau2: float = 1.0
    gem_c1: float = 0.50
    gem_c2: float = 0.50
    mg_v1: float = 0.03
    mg_v2: float = 0.04
    mg_v3: float = 0.03
    mg_sigma1: float = 0.50
    mg_sigma2: float = 1.0
    mg_sigma3: float = 2.0
    mg_radius1: float = 0.001
    mg_radius2: float = 0.01
    mg_radius3: float = 0.10
    mg_lambda1: float = 0.10
    mg_lambda2: float = 0.10
    mg_lambda3: float = 0.10
    poles: int = 68
    tolerance: float = 1e-6
    fit_min: float = 1e-2
    fit_max: float = 1e7
    rate_min: float = 1e-6
    rate_max: float = 1e10
    fit_samples: int = 256
    check_samples: int = 1024
    refine_sweeps: int = 2
    prune: bool = False

    def native(self):
        return np.asfortranarray(np.array([
            self.sigma_inf, self.chargeability, self.tau_rho, self.cole_c,
            self.gem_v1, self.gem_v2, self.gem_tau1, self.gem_tau2,
            self.gem_c1, self.gem_c2, self.mg_v1, self.mg_v2, self.mg_v3,
            self.mg_sigma1, self.mg_sigma2, self.mg_sigma3,
            self.mg_radius1, self.mg_radius2, self.mg_radius3,
            self.mg_lambda1, self.mg_lambda2, self.mg_lambda3,
        ], dtype=np.float64))


class Native:
    def __init__(self):
        suffix = ("libfig2_core.dylib" if sys.platform == "darwin" else
                  "fig2_core.dll" if sys.platform == "win32" else "libfig2_core.so")
        path = ROOT / "bin" / suffix
        if not path.is_file():
            raise FileNotFoundError(f"Run setup for the current platform: {path}")
        self._lib = ctypes.CDLL(str(path))
        try:
            self._fn = self._lib.ip_eval
        except AttributeError as exc:
            raise RuntimeError(
                f"Missing native symbol ip_eval in {path}. Run the setup script to rebuild the Fortran library."
            ) from exc
        vector = np.ctypeslib.ndpointer(dtype=np.float64, flags="F_CONTIGUOUS")
        self._fn.argtypes = [ctypes.c_int] + [vector] * 9 + [ctypes.POINTER(ctypes.c_int)]
        self._fn.restype = None

    def evaluate(self, s: np.ndarray, params: Parameters):
        s = np.asarray(s, dtype=np.complex128).ravel()
        if not len(s):
            raise ValueError("At least one Laplace sample is required")
        real = np.asfortranarray(s.real)
        imag = np.asfortranarray(s.imag)
        output = [np.empty((4, len(s)), dtype=np.float64, order="F") for _ in range(4)]
        rates = np.empty(4, dtype=np.float64, order="F")
        exact_weight = np.empty(4, dtype=np.float64, order="F")
        status = ctypes.c_int()
        self._fn(len(s), real, imag, params.native(), *output, rates, exact_weight,
                 ctypes.byref(status))
        if status.value:
            raise ValueError("Invalid constitutive parameters")
        normalized = output[0] + 1j * output[1]
        conductivity = output[2] + 1j * output[3]
        if not (np.isfinite(normalized).all() and np.isfinite(conductivity).all()):
            raise ValueError("Non-finite constitutive response")
        return normalized, conductivity, rates, exact_weight


@dataclass
class Result:
    frequency: np.ndarray
    phases: np.ndarray
    poles: np.ndarray
    weights: np.ndarray
    errors: np.ndarray
    exact_rates: np.ndarray
    accepted_moves: int
    params: Parameters
    validated: bool


def _weight_fit(samples: np.ndarray, response: np.ndarray, poles: np.ndarray, basis: np.ndarray):
    denom = 1e-7 + np.abs(response)
    scaled = basis / denom[:, None]
    target = response / denom
    nreal = len(samples) // 2
    design = np.vstack([
        scaled[:nreal].real,
        scaled[nreal:].real,
        1.25 * scaled[nreal:].imag,
        np.full((1, len(poles)), 30.0),
    ])
    rhs = np.r_[target[:nreal].real, target[nreal:].real,
                1.25 * target[nreal:].imag, [30.0]]
    weights, _ = nnls(design, rhs, maxiter=max(1000, 20 * len(poles)))
    weights = np.clip(weights, 0.0, None)
    total = float(weights.sum())
    if total <= 0:
        raise ArithmeticError("Nonnegative spectral fitting failed")
    return weights / total


def _error(samples: np.ndarray, targets: np.ndarray, poles: np.ndarray, weights: np.ndarray):
    basis = samples[:, None] / (samples[:, None] + poles[None, :])
    calculated = (basis @ weights.T).T
    return np.max(np.abs(calculated - targets) / (1e-7 + np.abs(targets)), axis=1)


def optimize(p: Parameters, notify: Callable[[str], None] | None = None):
    log = notify or (lambda message: None)
    if not (12 <= p.poles <= 160):
        raise ValueError("Pole budget must be between 12 and 160")
    if not (p.rate_min > 0 and p.rate_max > p.rate_min and
            p.fit_min > 0 and p.fit_max > p.fit_min and 0 < p.tolerance < 1):
        raise ValueError("Invalid optimization range or tolerance")
    native = Native()
    fit_rates = np.geomspace(p.fit_min, p.fit_max, p.fit_samples // 2)
    samples = np.r_[fit_rates.astype(np.complex128), 1j * fit_rates]
    targets, _, exact, exact_w = native.evaluate(samples, p)
    if any((exact < p.rate_min) | (exact > p.rate_max)):
        raise ValueError("Analytical rates fall outside the selected rate interval")
    free_count = p.poles - len(exact)
    if free_count < 4:
        raise ValueError("Insufficient free pole positions")
    poles = np.sort(np.r_[np.geomspace(p.rate_min, p.rate_max, free_count), exact])
    locked = np.array([np.min(np.abs(np.log(q / exact))) < 1e-12 for q in poles])
    test_rates = np.geomspace(p.fit_min, p.fit_max, p.check_samples)
    checks = np.r_[test_rates.astype(np.complex128), 1j * test_rates]
    verification, _, _, _ = native.evaluate(checks, p)

    def fit_trial(candidate: np.ndarray):
        basis = samples[:, None] / (samples[:, None] + candidate[None, :])
        weights = np.zeros((4, len(candidate)))
        for i in (1, 2):
            weights[i] = _weight_fit(samples, targets[i], candidate, basis)
        for row, positions in ((0, (0,)), (3, (1, 2, 3))):
            for k in positions:
                j = int(np.argmin(np.abs(np.log(candidate / exact[k]))))
                if not np.isclose(candidate[j], exact[k], rtol=1e-12):
                    raise ArithmeticError("The exact analytical pole has changed")
                weights[row, j] += exact_w[k]
        return weights, _error(checks, verification, candidate, weights)

    moves = 0
    log(f"Optimizing {p.poles} common poles; {len(exact)} fixed analytical rates")
    with threadpool_limits(limits=1):
        weights, errors = fit_trial(poles)
        if p.refine_sweeps:
            low = np.log10(p.rate_min)
            high = np.log10(p.rate_max)

            def objective(bounds):
                a, b = bounds
                if b - a < 6:
                    return 1e4
                trial = np.sort(np.r_[np.geomspace(10**a, 10**b, free_count), exact])
                _, errs = fit_trial(trial)
                return np.log10(max(errs[1], errs[2], 1e-16))

            lim = min(3, 0.25 * (high-low))
            search = minimize(objective, [low, high], method="Powell",
                              bounds=[(low, low+lim), (high-lim, high)],
                              options={"maxfev": 90, "xtol": 1e-3, "ftol": 1e-4})
            candidate = np.sort(np.r_[np.geomspace(10**search.x[0], 10**search.x[1], free_count), exact])
            w, e = fit_trial(candidate)
            if max(e[1], e[2]) < max(errors[1], errors[2]) * (1 - 1e-4):
                poles, weights, errors = candidate, w, e
                locked = np.array([np.min(np.abs(np.log(q / exact))) < 1e-12 for q in poles])
                moves += free_count
            log(f"Optimized support; maximum error: {max(errors):.3e}")

        for sweep in range(p.refine_sweeps):
            step = 0.16 / (2 ** sweep)
            influence = np.max(weights[1:3], axis=0)
            visited = 0
            for idx in np.argsort(influence)[::-1]:
                if locked[idx] or visited >= 12:
                    continue
                visited += 1
                best = float(max(errors[1], errors[2]))
                chosen = None
                for sign in (-1, 1):
                    test = poles.copy()
                    test[idx] *= 10 ** (step * sign)
                    if test[idx] <= p.rate_min or test[idx] >= p.rate_max:
                        continue
                    if idx > 0 and test[idx] <= poles[idx - 1] * (1 + 1e-8):
                        continue
                    if idx + 1 < len(test) and test[idx] >= poles[idx + 1] * (1 - 1e-8):
                        continue
                    w, e = fit_trial(test)
                    score = float(max(e[1], e[2]))
                    if score < best * (1 - 1e-4):
                        best, chosen = score, (test, w, e)
                if chosen is not None:
                    poles, weights, errors = chosen
                    moves += 1
            log(f"Refinement {sweep + 1}: maximum error {max(errors):.3e}")

        if p.prune:
            for _ in range(len(poles) - 8):
                ranking = np.argsort(np.max(weights[1:3], axis=0))
                accepted = False
                for idx in ranking[:12]:
                    if locked[idx]:
                        continue
                    trial = np.delete(poles, idx)
                    w, e = fit_trial(trial)
                    if max(e) <= p.tolerance:
                        poles, weights, errors = trial, w, e
                        locked = np.delete(locked, idx)
                        accepted = True
                        break
                if not accepted:
                    break

    frequency = np.geomspace(1e-3, 1e3, 501)
    _, conductivity, _, _ = native.evaluate(1j * 2 * np.pi * frequency, p)
    phase = np.abs(np.angle(1 / conductivity)) * 1000.0
    return Result(frequency, phase, poles, weights, errors, exact, moves,
                  p, bool(max(errors) <= p.tolerance))


def export_data(result: Result, folder: str | Path):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    np.savetxt(folder / "phase_spectra.csv", np.column_stack([result.frequency, *result.phases]),
               delimiter=",", comments="",
               header="frequency_Hz,Debye_mrad,Cole_Cole_mrad,GEMTIP_mrad,MGEMTIP_mrad")
    np.savetxt(folder / "pole_weights.csv", np.column_stack([result.poles, *result.weights]),
               delimiter=",", comments="",
               header="rate_per_s,Debye,Cole_Cole,GEMTIP,MGEMTIP")
    record = {"parameters": asdict(result.params), "count": len(result.poles),
              "validated": result.validated, "moves": result.accepted_moves,
              "errors": dict(zip(MODELS, map(float, result.errors)))}
    (folder / "fit_summary.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
