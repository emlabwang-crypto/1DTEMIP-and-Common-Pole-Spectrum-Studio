"""Light editor palettes."""

PALETTES = {
    "Light Modern": ("#ffffff", "#f3f3f3", "#e9e9e9", "#222222", "#006ab1", "#d6d6d6"),
    "Light+": ("#ffffff", "#f8f8f8", "#efefef", "#333333", "#007acc", "#d9d9d9"),
    "Solarized Light": ("#fdf6e3", "#eee8d5", "#e6dfc8", "#586e75", "#268bd2", "#c6c0b1"),
    "Quiet Light": ("#f5f8fa", "#ffffff", "#eef4f6", "#334451", "#397b8e", "#cddce2"),
    "High Contrast Light": ("#ffffff", "#f1f1f1", "#e5e5e5", "#101010", "#0052a4", "#737373"),
}


def stylesheet(name: str, font_size: int) -> str:
    bg, panel, input_bg, fg, accent, border = PALETTES[name]
    return f"""
    QWidget {{ background-color: {bg}; color: {fg}; font-size: {font_size}pt; }}
    QMainWindow, QSplitter, QScrollArea {{ background-color: {bg}; }}
    QFrame#panel, QTabWidget::pane {{ background-color: {panel}; border: 1px solid {border}; }}
    QLineEdit, QComboBox, QSpinBox {{ background-color: {input_bg}; border: 1px solid {border};
        padding: 6px 8px; min-height: 25px; border-radius: 4px; color: {fg}; }}
    QLineEdit:focus, QComboBox:focus, QSpinBox:focus {{ border: 1px solid {accent}; }}
    QPushButton {{ background-color: {input_bg}; border: 1px solid {border};
        border-radius: 4px; padding: 7px 13px; min-height: 25px; }}
    QPushButton:hover {{ border: 1px solid {accent}; }}
    QPushButton#run {{ background-color: {accent}; color: #ffffff; font-weight: 600; border: 0; }}
    QPushButton#run:disabled {{ background-color: {border}; }}
    QTabBar::tab {{ background-color: {panel}; border: 1px solid {border};
        padding: 8px 12px; margin-right: 1px; }}
    QTabBar::tab:selected {{ border-bottom: 2px solid {accent}; }}
    QScrollBar:vertical {{ background: {panel}; width: 10px; }}
    QScrollBar::handle:vertical {{ background: {border}; border-radius: 4px; }}
    QStatusBar {{ border-top: 1px solid {border}; }}
    """
