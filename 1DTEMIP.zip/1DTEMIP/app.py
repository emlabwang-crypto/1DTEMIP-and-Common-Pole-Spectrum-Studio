#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/"src"))
from longwire_ip_gui.gui import run_gui
if __name__ == "__main__":
    raise SystemExit(run_gui())
