# 1D TEM-IP Studio

Python 3.12 recommended.

## macOS

```bash
bash setup_macos.sh
bash run_macos.sh
```

## Windows

```bat
setup_windows.bat
run_windows.bat
```
