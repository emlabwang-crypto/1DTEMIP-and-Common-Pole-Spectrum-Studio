"""Observation-time readers for plain tables and all_ip time.txt files."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import re
import numpy as np


@dataclass(frozen=True)
class TimeReadResult:
    times_s: np.ndarray
    source_format: str
    unit: str
    path: str


def _noncomment_lines(path: Path) -> list[str]:
    lines: list[str] = []
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        s = raw.strip()
        if not s or s.startswith(("#", "!", "%", ";")):
            continue
        lines.append(s)
    return lines


def _float_tokens(line: str) -> list[float]:
    out: list[float] = []
    for tok in re.split(r"[\s,;]+", line.strip()):
        try:
            out.append(float(tok.replace("D", "E").replace("d", "e")))
        except ValueError:
            pass
    return out


def _validate(times: np.ndarray) -> np.ndarray:
    times = np.asarray(times, dtype=float).reshape(-1)
    if times.size == 0:
        raise ValueError("No time channels found in file")
    if not np.all(np.isfinite(times)):
        raise ValueError("Time channels contain NaN or infinity")
    if np.any(times <= 0.0):
        raise ValueError("All switch-off times must be positive")
    if np.any(np.diff(times) <= 0.0):
        raise ValueError("Time channels must increase strictly. Automatic sorting is disabled to preserve 3D alignment.")
    return times


def read_observation_times(path: str | Path, column: int = 1,
                           unit: str = "auto") -> TimeReadResult:
    """Read observation times.

    Supported formats
    -----------------
    1. all_ip ``time.txt``: reads N_CHANNEL values following CHANNEL_MODE.
    2. Plain whitespace/CSV table: reads the selected 1-based numeric column.

    ``unit`` is auto/s/ms/us/ns for plain tables. all_ip TIME_UNIT is honored.
    """
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(p)
    lines = _noncomment_lines(p)
    upper = [x.upper() for x in lines]

    # all_ip format.
    nidx = next((i for i, x in enumerate(upper) if x.startswith("N_CHANNEL")), None)
    midx = next((i for i, x in enumerate(upper) if x.startswith("CHANNEL_MODE")), None)
    if nidx is not None and midx is not None:
        ntok = lines[nidx].split()
        if len(ntok) < 2:
            raise ValueError("N_CHANNEL line does not specify a count")
        n = int(ntok[1])
        vals: list[float] = []
        i = midx + 1
        while i < len(lines) and len(vals) < n:
            nums = _float_tokens(lines[i])
            if nums:
                vals.append(nums[0])
            i += 1
        if len(vals) != n:
            raise ValueError(f"N_CHANNEL={n}, but found only {len(vals)} time channels")
        file_unit = "s"
        tidx = next((i for i, x in enumerate(upper) if x.startswith("TIME_UNIT")), None)
        if tidx is not None:
            tok = lines[tidx].split()
            if len(tok) >= 2:
                file_unit = tok[1].lower().replace("μ", "u").replace("µ", "u")
        scale = _unit_scale(file_unit)
        return TimeReadResult(_validate(np.asarray(vals)*scale), "all_ip TIME_FILE", file_unit, str(p))

    # Plain table.
    if column < 1:
        raise ValueError("Time column numbering starts at 1")
    vals = []
    for line_no, line in enumerate(lines, 1):
        nums = _float_tokens(line)
        if not nums:
            continue
        if len(nums) < column:
            raise ValueError(f"Layer or row {line_no} valid data row has only {len(nums)} columns; cannot read column {column} column")
        vals.append(nums[column-1])
    use_unit = "s" if unit.lower() == "auto" else unit.lower()
    scale = _unit_scale(use_unit)
    return TimeReadResult(_validate(np.asarray(vals)*scale), "plain numeric table", use_unit, str(p))


def _unit_scale(unit: str) -> float:
    u = unit.lower().strip().replace("μ", "u").replace("µ", "u")
    mapping = {"s": 1.0, "sec": 1.0, "second": 1.0,
               "ms": 1e-3, "us": 1e-6, "ns": 1e-9}
    if u not in mapping:
        raise ValueError(f"Unsupported time unit: {unit}; choose s/ms/us/ns")
    return mapping[u]
