"""Scalar conductivity models for layered-earth IP responses."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence
import math
import numpy as np


@dataclass(frozen=True)
class GemtipPhase:
    fraction: float
    tau: float
    exponent: float
    gamma: tuple[float, float, float] = (1/3, 1/3, 1/3)
    structural_factor: tuple[float, float, float] = (1.0, 1.0, 1.0)


@dataclass(frozen=True)
class MgemtipPhaseInput:
    fraction: float
    inclusion_sigma: float
    radius: float
    surface_factor: float


@dataclass(frozen=True)
class MgemtipPhase:
    fraction: float
    inclusion_sigma: float
    radius: float
    surface_factor: float
    tau: float
    eta: float


@dataclass
class IPModel:
    kind: str
    sigma_inf: float
    legacy: tuple[float, float, float, float] = (0.0, 0.0, 0.0, 0.0)
    gemtip_phases: list[GemtipPhase] = field(default_factory=list)
    mgemtip_input: list[MgemtipPhaseInput] = field(default_factory=list)
    mgemtip_phases: list[MgemtipPhase] = field(default_factory=list)
    sigma0_ratio: float = 1.0
    background_sigma: float = 0.0

    def finalize(self) -> "IPModel":
        kind = self.kind.upper()
        self.kind = kind
        if not (math.isfinite(self.sigma_inf) and self.sigma_inf > 0):
            raise ValueError("sigma_inf must be finite and positive")

        if kind == "NONE":
            self.sigma0_ratio = 1.0
        elif kind in {"DEBYE", "COLE_COLE"}:
            m, tau, alpha, _ = self.legacy
            if not (0 <= m < 1):
                raise ValueError("chargeability m must satisfy 0 <= m < 1")
            if tau <= 0:
                raise ValueError("tau must be positive")
            if kind == "COLE_COLE" and not (0 < alpha <= 1):
                raise ValueError("Cole-Cole exponent c must satisfy 0 < c <= 1")
            self.sigma0_ratio = 1.0-m
        elif kind == "GEMTIP":
            if not self.gemtip_phases:
                raise ValueError("GEMTIP requires at least one phase")
            fsum = 0.0
            amplitude = 0.0
            for phase in self.gemtip_phases:
                _validate_gemtip(phase)
                fsum += phase.fraction
                amplitude += sum(phase.fraction/(3.0*g) for g in phase.gamma)
            if not fsum < 1.0:
                raise ValueError("GEMTIP sum of volume fractions must be < 1")
            if not amplitude > 0.0:
                raise ValueError("GEMTIP total polarizable fraction must be positive")
            self.sigma0_ratio = 1.0/(1.0+amplitude)
        elif kind == "MGEMTIP":
            if not self.mgemtip_input:
                raise ValueError("MGEMTIP requires at least one phase")
            for phase in self.mgemtip_input:
                _validate_mgemtip_input(phase)
            fsum = sum(p.fraction for p in self.mgemtip_input)
            m0 = 1.0-1.5*fsum
            if m0 <= 0:
                raise ValueError("MGEMTIP requires M0=1-3*sum(f)/2 > 0")
            target = self.sigma_inf
            lo = 0.0
            hi = max(target/m0, target)
            while _mgemtip_high_sigma(hi, m0, self.mgemtip_input) < target:
                hi *= 2.0
                if not math.isfinite(hi):
                    raise ValueError("failed to bracket MGEMTIP background conductivity")
            for _ in range(160):
                mid = 0.5*(lo+hi)
                value = _mgemtip_high_sigma(mid, m0, self.mgemtip_input)
                if value < target:
                    lo = mid
                else:
                    hi = mid
                if hi-lo <= 1e-13*max(target, hi):
                    break
            sigma_b = 0.5*(lo+hi)
            out: list[MgemtipPhase] = []
            eta_sum = 0.0
            for p in self.mgemtip_input:
                tau = p.radius*p.surface_factor*(2*sigma_b+p.inclusion_sigma)/(2*sigma_b*p.inclusion_sigma)
                eta = 9*p.fraction*p.inclusion_sigma/((4*sigma_b+2*p.inclusion_sigma)*m0)
                if not (math.isfinite(tau) and tau > 0 and math.isfinite(eta) and eta >= 0):
                    raise ValueError("invalid computed MGEMTIP phase")
                out.append(MgemtipPhase(p.fraction, p.inclusion_sigma, p.radius,
                                        p.surface_factor, tau, eta))
                eta_sum += eta
            if eta_sum <= 0:
                raise ValueError("MGEMTIP total polarizability must be positive")
            self.background_sigma = sigma_b
            self.mgemtip_phases = out
            self.sigma0_ratio = sigma_b*m0/target
            if not (0 < self.sigma0_ratio < 1):
                raise ValueError("MGEMTIP endpoint ratio must lie in (0,1)")
        else:
            raise ValueError(f"unsupported model {kind}")
        return self

    @property
    def sigma0(self) -> float:
        return self.sigma_inf*self.sigma0_ratio

    @property
    def delta_sigma(self) -> float:
        return self.sigma_inf-self.sigma0

    def transfer(self, s: np.ndarray | complex) -> np.ndarray:
        s_arr = np.asarray(s, dtype=np.complex128)
        kind = self.kind
        if kind == "NONE":
            return np.zeros_like(s_arr)
        m, tau, alpha, _ = self.legacy
        if kind == "COLE_COLE":
            z = (1.0-m)*(s_arr*tau)**alpha
            return z/(1.0+z)
        if kind == "DEBYE":
            z = (1.0-m)*(s_arr*tau)
            return z/(1.0+z)
        if kind == "GEMTIP":
            num = np.zeros_like(s_arr)
            den = 0.0
            for p in self.gemtip_phases:
                z = (s_arr*p.tau)**p.exponent
                for gamma, sf in zip(p.gamma, p.structural_factor):
                    w = p.fraction/(3.0*gamma)
                    h = 1.0-1.0/(1.0+sf*z)
                    num += w*h
                    den += w
            return num/den
        if kind == "MGEMTIP":
            num = np.zeros_like(s_arr)
            den = 0.0
            for p in self.mgemtip_phases:
                h = 1.0-1.0/(1.0+s_arr*p.tau)
                num += p.eta*h
                den += p.eta
            return num/den
        raise RuntimeError(f"unfinalized/unknown model {kind}")

    def sigma(self, frequency_hz: np.ndarray | float) -> np.ndarray:
        """Complex conductivity at positive Fourier frequency, s=i*2*pi*f."""
        freq = np.asarray(frequency_hz, dtype=float)
        s = 2j*np.pi*freq
        return self.sigma0+self.delta_sigma*self.transfer(s)

    def metadata(self) -> dict:
        out = {
            "kind": self.kind,
            "sigma_inf_S_per_m": self.sigma_inf,
            "sigma0_S_per_m": self.sigma0,
            "sigma0_ratio": self.sigma0_ratio,
            "rho_inf_ohm_m": 1.0/self.sigma_inf,
            "rho0_ohm_m": 1.0/self.sigma0,
            "legacy": list(self.legacy),
        }
        if self.gemtip_phases:
            out["gemtip_phases"] = [p.__dict__ for p in self.gemtip_phases]
        if self.mgemtip_phases:
            out["background_sigma_S_per_m"] = self.background_sigma
            out["mgemtip_phases"] = [p.__dict__ for p in self.mgemtip_phases]
        return out


def _validate_gemtip(p: GemtipPhase) -> None:
    if not (0 <= p.fraction < 1):
        raise ValueError("GEMTIP fraction must be in [0,1)")
    if p.tau <= 0 or not (0 < p.exponent <= 1):
        raise ValueError("GEMTIP tau/exponent invalid")
    if any((not math.isfinite(x) or x <= 0) for x in p.gamma):
        raise ValueError("GEMTIP gamma values must be positive")
    if abs(sum(p.gamma)-1.0) > 1e-8:
        raise ValueError("GEMTIP gamma_x+gamma_y+gamma_z must equal 1")
    if any((not math.isfinite(x) or x <= 0) for x in p.structural_factor):
        raise ValueError("GEMTIP structural factors must be positive")


def _validate_mgemtip_input(p: MgemtipPhaseInput) -> None:
    if not (0 <= p.fraction < 1):
        raise ValueError("MGEMTIP fraction must be in [0,1)")
    if p.inclusion_sigma <= 0 or p.radius <= 0 or p.surface_factor <= 0:
        raise ValueError("MGEMTIP conductivity/radius/surface factor must be positive")


def _mgemtip_high_sigma(sigma_b: float, m0: float,
                         phases: Sequence[MgemtipPhaseInput]) -> float:
    value = sigma_b*m0
    for p in phases:
        value += 9.0*p.fraction*sigma_b*p.inclusion_sigma/(4.0*sigma_b+2.0*p.inclusion_sigma)
    return value
