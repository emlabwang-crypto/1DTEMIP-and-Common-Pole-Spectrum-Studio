"""Finite-wire transient solver for layered isotropic and VTI media."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import copy
from pathlib import Path
from typing import Callable
import json
import math
import sys
import time

import numpy as np

if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
    _ROOT = Path(sys._MEIPASS)
else:
    _ROOT = Path(__file__).resolve().parents[2]
_VENDOR = _ROOT / "vendor"
if str(_VENDOR) not in sys.path:
    sys.path.insert(0, str(_VENDOR))
import empymod  # noqa: E402

from .config import EarthLayer, Receiver, SimulationConfig, model_to_input_dict

MU0 = 4.0e-7 * np.pi
HANKEL_FILTERS = {"key_201_2009", "key_401_2009"}
FOURIER_FILTERS = {"key_201_2012", "key_601_2009"}


@dataclass
class SimulationResult:
    times_s: np.ndarray
    values: np.ndarray  # [ntime, nreceiver]
    receiver_names: list[str]
    units: list[str]
    elapsed_s: float
    metadata: dict


def _eta_hook_uniform(model, air_sigma: float):
    """Complex conductivity callback for a homogeneous half-space."""

    def hook(inp: dict, p_dict: dict):
        freq = np.asarray(p_dict["freq"], dtype=float).reshape(-1)
        sigma_ground = np.asarray(model.sigma(freq), dtype=np.complex128).reshape(-1)
        eta = np.empty((freq.size, 2), dtype=np.complex128)
        eta[:, 0] = air_sigma
        eta[:, 1] = sigma_ground
        return eta, eta.copy()

    return hook




def _eta_hook_layered_isotropic_legacy(models, air_sigma: float):
    """Complex conductivity callback for isotropic layers."""

    def hook(inp: dict, p_dict: dict):
        freq = np.asarray(p_dict["freq"], dtype=float).reshape(-1)
        eta = np.empty((freq.size, len(models) + 1), dtype=np.complex128)
        eta[:, 0] = air_sigma
        for index, model in enumerate(models, 1):
            eta[:, index] = np.asarray(model.sigma(freq), dtype=np.complex128).reshape(-1)
        return eta, eta.copy()

    return hook


def _eta_hook_layered_vti(horizontal_models, vertical_models, air_sigma: float):
    """Return exact frequency-dependent VTI conductivities etaH and etaV."""
    if len(horizontal_models) != len(vertical_models):
        raise ValueError("H and V model counts differ")

    def hook(inp: dict, p_dict: dict):
        freq = np.asarray(p_dict["freq"], dtype=float).reshape(-1)
        eta_h = np.empty((freq.size, len(horizontal_models) + 1), dtype=np.complex128)
        eta_v = np.empty_like(eta_h)
        eta_h[:, 0] = air_sigma
        eta_v[:, 0] = air_sigma
        for index, (model_h, model_v) in enumerate(
            zip(horizontal_models, vertical_models), 1
        ):
            eta_h[:, index] = np.asarray(
                model_h.sigma(freq), dtype=np.complex128
            ).reshape(-1)
            eta_v[:, index] = np.asarray(
                model_v.sigma(freq), dtype=np.complex128
            ).reshape(-1)
        return eta_h, eta_v

    return hook


def _surface_trace(z: float, eps: float) -> float:
    """Original homogeneous interface convention: evaluate z=0 in earth."""
    return eps if abs(z) <= eps / 100.0 else float(z)


def _interfaces(layers: list[EarthLayer]) -> np.ndarray:
    depth = [0.0]
    total = 0.0
    for layer in layers[:-1]:
        if layer.thickness_m is None:
            raise ValueError("Only the last layer may be a half-space")
        total += float(layer.thickness_m)
        depth.append(total)
    return np.asarray(depth, dtype=float)


def _lower_trace(z: float, interfaces: np.ndarray, eps: float) -> float:
    """Evaluate exact interface coordinates on the lower-side limiting trace."""
    value = float(z)
    for boundary in interfaces:
        tolerance = max(
            eps / 100.0,
            64.0 * np.finfo(float).eps * max(1.0, abs(float(boundary))),
        )
        if abs(value - boundary) <= tolerance:
            return float(boundary + eps)
    return value


def _orientation(component: str) -> tuple[float, float]:
    value = component.upper()
    if value == "X":
        return 0.0, 0.0
    if value == "Y":
        return 90.0, 0.0
    if value == "Z":
        return 0.0, 90.0
    raise ValueError(f"Unknown component {component}")


def _receiver_mode_uniform(receiver: Receiver):
    """Original homogeneous output convention."""
    quantity = receiver.quantity.upper()
    if quantity == "E":
        return False, 1.0, "V/m"
    if quantity == "H":
        return True, 1.0, "A/m"
    if quantity == "B":
        return True, MU0, "T"
    if quantity in {"DBDT", "DB/DT", "DB_DT"}:
        return "b", 1.0, "T/s"
    raise ValueError(f"Unknown observable {receiver.quantity}")


def _receiver_mode_layered(receiver: Receiver, mu_r: float):
    quantity = receiver.quantity.upper()
    if quantity == "E":
        return False, 1.0, "V/m"
    if quantity == "H":
        return True, 1.0, "A/m"
    if quantity == "B":
        return True, MU0 * mu_r, "T"
    if quantity in {"DBDT", "DB/DT", "DB_DT"}:
        return "b", 1.0, "T/s"
    raise ValueError(f"Unknown observable {receiver.quantity}")


def _layer_index(z: float, interfaces: np.ndarray) -> int:
    """Earth-layer index for positive-down z; -1 denotes air."""
    if z < 0.0:
        return -1
    return int(np.searchsorted(interfaces[1:], z, side="right"))


def _model_signature(layer: EarthLayer) -> str:
    """Canonical physical-input signature used for exact interface collapse."""
    layer.finalize()
    payload = {
        "mu_r": float(layer.mu_r),
        "horizontal_model": model_to_input_dict(layer.model),
        "vertical_model": model_to_input_dict(layer.vertical_model),
    }
    return json.dumps(payload, sort_keys=True, separators=(",", ":"))


def layer_is_isotropic(layer: EarthLayer) -> bool:
    layer.finalize()
    return layer.is_electrically_isotropic


def isotropic_equivalent(layers: list[EarthLayer]) -> bool:
    """True if every layer has sigma_H(s) exactly equal to sigma_V(s)."""
    return bool(layers) and all(layer_is_isotropic(layer) for layer in layers)


def homogeneous_equivalent(layers: list[EarthLayer]) -> bool:
    """True when all earth layers have exactly the same H/V electromagnetic data."""
    if not layers:
        return False
    for layer in layers:
        layer.finalize()
    first = _model_signature(layers[0])
    return all(_model_signature(layer) == first for layer in layers[1:])


def collapse_identical_layers(layers: list[EarthLayer]) -> list[EarthLayer]:
    """Remove interfaces between adjacent layers with identical H/V properties."""
    if not layers:
        return []
    collapsed: list[EarthLayer] = []
    for original in layers:
        layer = copy.deepcopy(original).finalize()
        if collapsed and _model_signature(collapsed[-1]) == _model_signature(layer):
            previous = collapsed[-1]
            if layer.thickness_m is None:
                previous.thickness_m = None
            elif previous.thickness_m is not None:
                previous.thickness_m += layer.thickness_m
            continue
        collapsed.append(layer)
    return collapsed


def _use_original_uniform_path(layers: list[EarthLayer]) -> bool:
    """Select the homogeneous isotropic solver."""
    return (
        homogeneous_equivalent(layers)
        and isotropic_equivalent(layers)
        and math.isclose(layers[0].mu_r, 1.0, rel_tol=0.0, abs_tol=0.0)
    )


def isotropic_limit_config(config: SimulationConfig) -> SimulationConfig:
    """Deep copy with every vertical model replaced by its horizontal model."""
    cloned = copy.deepcopy(config)
    for layer in cloned.layers:
        layer.make_isotropic_from_horizontal()
    return cloned


def anisotropy_summary(config: SimulationConfig) -> dict:
    """Return a compact diagnostic used by the GUI and validation reports."""
    layers = config.finalized_layers()
    collapsed = collapse_identical_layers(layers)
    anisotropic = [index + 1 for index, layer in enumerate(layers) if not layer_is_isotropic(layer)]
    return {
        "supported_class": "1-D VTI",
        "relation": "sigma_x=sigma_y=sigma_H; sigma_z=sigma_V",
        "layer_count": len(layers),
        "collapsed_layer_count": len(collapsed),
        "anisotropic_layers": anisotropic,
        "isotropic_limit": len(anisotropic) == 0,
        "original_uniform_path": _use_original_uniform_path(layers),
    }


def validate_config(config: SimulationConfig) -> None:
    layers = config.finalized_layers()
    if not config.receivers:
        raise ValueError("At least one receiver is required")
    times = np.asarray(config.times_s, dtype=float)
    if (
        times.size == 0
        or np.any(~np.isfinite(times))
        or np.any(times <= 0.0)
        or np.any(np.diff(times) <= 0.0)
    ):
        raise ValueError("Time channels must be strictly increasing positive values")

    source = config.source
    delta = np.asarray(
        [source.x2 - source.x1, source.y2 - source.y1, source.z2 - source.z1],
        dtype=float,
    )
    if not np.all(np.isfinite(delta)) or np.linalg.norm(delta) <= 0.0:
        raise ValueError("Transmitter wire must have positive length")
    if not np.isfinite(source.current_a) or source.current_a <= 0.0:
        raise ValueError("Pre-switch-off current must be positive")

    for receiver in config.receivers:
        if not np.all(np.isfinite([receiver.x, receiver.y, receiver.z])):
            raise ValueError(f"Receiver “{receiver.name}” coordinates must be finite")
        _orientation(receiver.component)
        _receiver_mode_uniform(receiver)

    numerics = config.numerics
    points = numerics.source_quadrature_points
    if points < 3 or points % 2 == 0:
        raise ValueError("Wire quadrature count must be odd and at least 3")
    if numerics.interface_epsilon_m <= 0.0:
        raise ValueError("Interface offset must be positive")
    if numerics.air_conductivity_s_per_m <= 0.0:
        raise ValueError("Air conductivity must be positive")
    if numerics.hankel_filter not in HANKEL_FILTERS:
        raise ValueError(f"Unsupported Hankel filter: {numerics.hankel_filter}")
    if numerics.fourier_filter not in FOURIER_FILTERS:
        raise ValueError(f"Unsupported Fourier filter: {numerics.fourier_filter}")
    if numerics.hankel_method not in {"dlf", "qwe"}:
        raise ValueError("Hankel method must be dlf or qwe")
    if numerics.qwe_rtol <= 0.0 or numerics.qwe_atol <= 0.0:
        raise ValueError("QWE rtol/atol must be positive")
    if numerics.qwe_nquad < 3 or numerics.qwe_maxint < 1:
        raise ValueError("Invalid QWE nquad/maxint")

    # Ensure finite layers define strictly increasing interfaces.
    depth = _interfaces(layers)
    if np.any(np.diff(depth) <= 0.0):
        raise ValueError("Layer interfaces must be strictly increasing in depth")


def _hankel_args(config: SimulationConfig, method: str | None = None):
    numerics = config.numerics
    selected = numerics.hankel_method if method is None else method
    if selected == "dlf":
        return "dlf", {
            "dlf": numerics.hankel_filter,
            "pts_per_dec": numerics.hankel_pts_per_dec,
        }
    if selected == "qwe":
        return "qwe", {
            "rtol": numerics.qwe_rtol,
            "atol": numerics.qwe_atol,
            "nquad": numerics.qwe_nquad,
            "maxint": numerics.qwe_maxint,
            "pts_per_dec": 0,
        }
    raise ValueError("Hankel method must be dlf or qwe")


def _real_time_array(em) -> np.ndarray:
    array = np.real_if_close(np.asarray(em).reshape(-1), tol=1000)
    if np.iscomplexobj(array):
        real_scale = max(float(np.max(np.abs(array.real))), 1.0e-300)
        if float(np.max(np.abs(array.imag))) > 1.0e-10 * real_scale:
            raise RuntimeError("Unexpected imaginary residual in time-domain response")
        array = array.real
    return np.asarray(array, dtype=float)


def _solve_uniform_original(
    config: SimulationConfig,
    model,
    progress: Callable[[int, str], None] | None,
    cancelled: Callable[[], bool] | None,
) -> SimulationResult:
    """Compute the homogeneous half-space response."""
    numerics = config.numerics
    eps = numerics.interface_epsilon_m
    times = np.asarray(config.times_s, dtype=float)
    source = [
        config.source.x1,
        config.source.x2,
        config.source.y1,
        config.source.y2,
        _surface_trace(config.source.z1, eps),
        _surface_trace(config.source.z2, eps),
    ]
    res = {
        "res": np.array(
            [1.0 / numerics.air_conductivity_s_per_m, 1.0 / model.sigma_inf]
        ),
        "func_eta": _eta_hook_uniform(model, numerics.air_conductivity_s_per_m),
    }
    ht, htarg = _hankel_args(config)
    ftarg = {
        "dlf": numerics.fourier_filter,
        "pts_per_dec": numerics.fourier_pts_per_dec,
    }
    values = np.empty((times.size, len(config.receivers)), dtype=float)
    units: list[str] = []
    started = time.perf_counter()

    for index, receiver in enumerate(config.receivers):
        if cancelled and cancelled():
            raise RuntimeError("Simulation cancelled")
        azimuth, dip = _orientation(receiver.component)
        rec = [
            receiver.x,
            receiver.y,
            _surface_trace(receiver.z, eps),
            azimuth,
            dip,
        ]
        mrec, scale, unit = _receiver_mode_uniform(receiver)
        if progress:
            progress(
                int(100 * index / max(1, len(config.receivers))),
                f"Computing receiver {index + 1}/{len(config.receivers)}：{receiver.name}",
            )
        em = empymod.bipole(
            src=source,
            rec=rec,
            depth=[0.0],
            res=res,
            freqtime=times,
            signal=-1,
            aniso=[1.0, 1.0],
            epermH=[0.0, 0.0],
            epermV=[0.0, 0.0],
            mpermH=[1.0, 1.0],
            mpermV=[1.0, 1.0],
            msrc=False,
            srcpts=numerics.source_quadrature_points,
            mrec=mrec,
            recpts=1,
            strength=config.source.current_a,
            ht=ht,
            htarg=htarg,
            ft="dlf",
            ftarg=ftarg,
            xdirect=False,
            verb=numerics.verbosity,
            squeeze=True,
        )
        values[:, index] = _real_time_array(em) * scale
        units.append(unit)

    elapsed = time.perf_counter() - started
    if progress:
        progress(100, "Simulation complete")
    metadata = {
        "solver": "validated original homogeneous-half-space path",
        "execution_path": "uniform_original",
        "homogeneous_layers_collapsed": len(config.layers),
        "hankel_method": numerics.hankel_method,
        "hankel_filter": numerics.hankel_filter if numerics.hankel_method == "dlf" else None,
        "fourier_filter": numerics.fourier_filter,
        "empymod_version": empymod.__version__,
        "signal": "ideal switch-off (unit step from I0 to zero at t=0)",
        "coordinate_system": "x East, y North, positive z downward",
        "source": asdict(config.source),
        "receivers": [asdict(x) for x in config.receivers],
        "numerics": asdict(numerics),
        "material": model.metadata(),
        "time_file": config.time_file,
        "ntime": int(times.size),
        "interface_note": "z=0 is evaluated epsilon inside the homogeneous earth",
    }
    return SimulationResult(
        times,
        values,
        [x.name for x in config.receivers],
        units,
        elapsed,
        metadata,
    )


def _layered_arrays(config: SimulationConfig):
    original_layers = config.finalized_layers()
    legacy_isotropic = isotropic_equivalent(original_layers)
    layers = (
        [copy.deepcopy(layer) for layer in original_layers]
        if legacy_isotropic
        else collapse_identical_layers(original_layers)
    )
    depth = _interfaces(layers)
    n_total = len(layers) + 1
    rho_h = np.empty(n_total, dtype=float)
    rho_h[0] = 1.0 / config.numerics.air_conductivity_s_per_m
    rho_h[1:] = [1.0 / layer.model.sigma_inf for layer in layers]
    aniso = np.ones(n_total, dtype=float)
    mu_r = np.asarray([1.0] + [layer.mu_r for layer in layers], dtype=float)
    zeros = np.zeros(n_total, dtype=float)
    if legacy_isotropic:
        res = {
            "res": rho_h,
            "func_eta": _eta_hook_layered_isotropic_legacy(
                [layer.model for layer in layers],
                config.numerics.air_conductivity_s_per_m,
            ),
        }
    else:
        aniso[1:] = [layer.high_frequency_anisotropy for layer in layers]
        res = {
            "res": rho_h,
            "func_eta": _eta_hook_layered_vti(
                [layer.model for layer in layers],
                [layer.vertical_model for layer in layers],
                config.numerics.air_conductivity_s_per_m,
            ),
        }
    return layers, depth, res, mu_r, aniso, zeros


def _solve_layered(
    config: SimulationConfig,
    progress: Callable[[int, str], None] | None,
    cancelled: Callable[[], bool] | None,
) -> SimulationResult:
    layers, depth, res, mu_r, aniso, zeros = _layered_arrays(config)
    numerics = config.numerics
    eps = numerics.interface_epsilon_m
    times = np.asarray(config.times_s, dtype=float)
    source = [
        config.source.x1,
        config.source.x2,
        config.source.y1,
        config.source.y2,
        _lower_trace(config.source.z1, depth, eps),
        _lower_trace(config.source.z2, depth, eps),
    ]
    ht, htarg = _hankel_args(config)
    ftarg = {
        "dlf": numerics.fourier_filter,
        "pts_per_dec": numerics.fourier_pts_per_dec,
    }
    values = np.empty((times.size, len(config.receivers)), dtype=float)
    units: list[str] = []
    started = time.perf_counter()

    for index, receiver in enumerate(config.receivers):
        if cancelled and cancelled():
            raise RuntimeError("Simulation cancelled")
        if progress:
            progress(
                int(100 * index / max(1, len(config.receivers))),
                f"Computing receiver {index + 1}/{len(config.receivers)}：{receiver.name}",
            )
        rec_z = _lower_trace(receiver.z, depth, eps)
        earth_index = _layer_index(rec_z, depth)
        receiver_mu_r = 1.0 if earth_index < 0 else layers[earth_index].mu_r
        azimuth, dip = _orientation(receiver.component)
        rec = [receiver.x, receiver.y, rec_z, azimuth, dip]
        mrec, scale, unit = _receiver_mode_layered(receiver, receiver_mu_r)
        em = empymod.bipole(
            src=source,
            rec=rec,
            depth=depth,
            res=res,
            freqtime=times,
            signal=-1,
            aniso=aniso,
            epermH=zeros,
            epermV=zeros,
            mpermH=mu_r,
            mpermV=mu_r,
            msrc=False,
            srcpts=numerics.source_quadrature_points,
            mrec=mrec,
            recpts=1,
            strength=config.source.current_a,
            ht=ht,
            htarg=htarg,
            ft="dlf",
            ftarg=ftarg,
            xdirect=False,
            verb=numerics.verbosity,
            squeeze=True,
        )
        values[:, index] = _real_time_array(em) * scale
        units.append(unit)

    elapsed = time.perf_counter() - started
    if progress:
        progress(100, "Simulation complete")
    metadata = {
        "solver": "empymod finite electric bipole in exact 1-D VTI layered earth",
        "execution_path": (
            "layered_isotropic_legacy" if isotropic_equivalent(layers) else
            ("vti_halfspace" if len(layers) == 1 else "layered_vti")
        ),
        "empymod_version": empymod.__version__,
        "signal": "ideal switch-off (I0 for t<0; zero for t>=0)",
        "coordinate_system": "x East, y North, positive z downward",
        "interfaces_m": depth.tolist(),
        "anisotropy": anisotropy_summary(config),
        "layers": [layer.metadata() for layer in layers],
        "hankel_method": numerics.hankel_method,
        "hankel_filter": numerics.hankel_filter if numerics.hankel_method == "dlf" else None,
        "fourier_filter": numerics.fourier_filter,
        "source": asdict(config.source),
        "receivers": [asdict(x) for x in config.receivers],
        "numerics": asdict(numerics),
        "time_file": config.time_file,
        "ntime": int(times.size),
        "interface_note": "exact interfaces use the lower-side epsilon trace",
    }
    return SimulationResult(
        times,
        values,
        [x.name for x in config.receivers],
        units,
        elapsed,
        metadata,
    )


def solve_stepoff(
    config: SimulationConfig,
    progress: Callable[[int, str], None] | None = None,
    cancelled: Callable[[], bool] | None = None,
) -> SimulationResult:
    """Compute the ideal switch-off response for all point receivers."""
    validate_config(config)
    layers = config.finalized_layers()
    if _use_original_uniform_path(layers):
        return _solve_uniform_original(config, layers[0].model, progress, cancelled)
    return _solve_layered(config, progress, cancelled)


def _frequency_uniform_original(
    config: SimulationConfig,
    model,
    frequencies: np.ndarray,
    receiver_index: int,
    hankel: str,
) -> np.ndarray:
    receiver = config.receivers[receiver_index]
    numerics = config.numerics
    eps = numerics.interface_epsilon_m
    source = [
        config.source.x1,
        config.source.x2,
        config.source.y1,
        config.source.y2,
        _surface_trace(config.source.z1, eps),
        _surface_trace(config.source.z2, eps),
    ]
    azimuth, dip = _orientation(receiver.component)
    rec = [receiver.x, receiver.y, _surface_trace(receiver.z, eps), azimuth, dip]
    mrec, scale, _ = _receiver_mode_uniform(receiver)
    res = {
        "res": np.array(
            [1.0 / numerics.air_conductivity_s_per_m, 1.0 / model.sigma_inf]
        ),
        "func_eta": _eta_hook_uniform(model, numerics.air_conductivity_s_per_m),
    }
    method, htarg = _hankel_args(config, hankel)
    em = empymod.bipole(
        src=source,
        rec=rec,
        depth=[0.0],
        res=res,
        freqtime=frequencies,
        signal=None,
        aniso=[1.0, 1.0],
        epermH=[0.0, 0.0],
        epermV=[0.0, 0.0],
        mpermH=[1.0, 1.0],
        mpermV=[1.0, 1.0],
        msrc=False,
        srcpts=numerics.source_quadrature_points,
        mrec=mrec,
        recpts=1,
        strength=config.source.current_a,
        ht=method,
        htarg=htarg,
        xdirect=False,
        verb=numerics.verbosity,
        squeeze=True,
    )
    return np.asarray(em).reshape(-1) * scale


def _frequency_layered(
    config: SimulationConfig,
    frequencies: np.ndarray,
    receiver_index: int,
    hankel: str,
) -> np.ndarray:
    layers, depth, res, mu_r, aniso, zeros = _layered_arrays(config)
    receiver = config.receivers[receiver_index]
    numerics = config.numerics
    eps = numerics.interface_epsilon_m
    source = [
        config.source.x1,
        config.source.x2,
        config.source.y1,
        config.source.y2,
        _lower_trace(config.source.z1, depth, eps),
        _lower_trace(config.source.z2, depth, eps),
    ]
    rec_z = _lower_trace(receiver.z, depth, eps)
    index = _layer_index(rec_z, depth)
    receiver_mu_r = 1.0 if index < 0 else layers[index].mu_r
    azimuth, dip = _orientation(receiver.component)
    rec = [receiver.x, receiver.y, rec_z, azimuth, dip]
    mrec, scale, _ = _receiver_mode_layered(receiver, receiver_mu_r)
    method, htarg = _hankel_args(config, hankel)
    em = empymod.bipole(
        src=source,
        rec=rec,
        depth=depth,
        res=res,
        freqtime=frequencies,
        signal=None,
        aniso=aniso,
        epermH=zeros,
        epermV=zeros,
        mpermH=mu_r,
        mpermV=mu_r,
        msrc=False,
        srcpts=numerics.source_quadrature_points,
        mrec=mrec,
        recpts=1,
        strength=config.source.current_a,
        ht=method,
        htarg=htarg,
        xdirect=False,
        verb=numerics.verbosity,
        squeeze=True,
    )
    return np.asarray(em).reshape(-1) * scale


def frequency_response(
    config: SimulationConfig,
    frequencies_hz: np.ndarray,
    receiver_index: int = 0,
    hankel: str = "dlf",
) -> np.ndarray:
    """Frequency-domain helper used by verification and diagnostics."""
    validate_config(config)
    frequencies = np.asarray(frequencies_hz, dtype=float)
    if frequencies.size == 0 or np.any(~np.isfinite(frequencies)) or np.any(frequencies <= 0.0):
        raise ValueError("Frequencies must be finite positive values")
    layers = config.finalized_layers()
    if _use_original_uniform_path(layers):
        return _frequency_uniform_original(
            config, layers[0].model, frequencies, receiver_index, hankel
        )
    return _frequency_layered(config, frequencies, receiver_index, hankel)


def write_results(result: SimulationResult, directory: str | Path) -> list[Path]:
    output = Path(directory)
    output.mkdir(parents=True, exist_ok=True)
    paths: list[Path] = []
    for index, name in enumerate(result.receiver_names):
        safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in name) or f"R{index + 1}"
        path = output / f"{index + 1:03d}_{safe}.csv"
        data = np.column_stack(
            (
                np.arange(1, result.times_s.size + 1),
                result.times_s,
                result.values[:, index],
            )
        )
        np.savetxt(
            path,
            data,
            delimiter=",",
            header=f"channel,time_s,value_{result.units[index]}",
            comments="",
            fmt=["%d", "%.16e", "%.16e"],
        )
        paths.append(path)

    path = output / "all_receivers_long.csv"
    with path.open("w", encoding="utf-8") as stream:
        stream.write("receiver_index,receiver_name,quantity_unit,channel,time_s,value\n")
        for index, name in enumerate(result.receiver_names):
            for channel, (tt, value) in enumerate(
                zip(result.times_s, result.values[:, index]), 1
            ):
                stream.write(
                    f'{index + 1},"{name}",{result.units[index]},{channel},'
                    f"{tt:.16e},{value:.16e}\n"
                )
    paths.append(path)
    (output / "metadata.json").write_text(
        json.dumps(
            {**result.metadata, "elapsed_s": result.elapsed_s},
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    return paths


def legacy_isotropic_frequency_response(
    config: SimulationConfig,
    frequencies_hz: np.ndarray,
    receiver_index: int = 0,
    hankel: str = "dlf",
) -> np.ndarray:
    """Frequency response for isotropic-limit validation."""
    validate_config(config)
    layers = config.finalized_layers()
    if not isotropic_equivalent(layers):
        raise ValueError("Legacy reference requires isotropy; set V=H")
    frequencies = np.asarray(frequencies_hz, dtype=float)
    if frequencies.size == 0 or np.any(~np.isfinite(frequencies)) or np.any(frequencies <= 0.0):
        raise ValueError("Frequencies must be finite positive values")
    if _use_original_uniform_path(layers):
        return _frequency_uniform_original(
            config, layers[0].model, frequencies, receiver_index, hankel
        )

    receiver = config.receivers[receiver_index]
    numerics = config.numerics
    eps = numerics.interface_epsilon_m
    depth = _interfaces(layers)
    source = [
        config.source.x1,
        config.source.x2,
        config.source.y1,
        config.source.y2,
        _lower_trace(config.source.z1, depth, eps),
        _lower_trace(config.source.z2, depth, eps),
    ]
    rec_z = _lower_trace(receiver.z, depth, eps)
    layer_index = _layer_index(rec_z, depth)
    receiver_mu_r = 1.0 if layer_index < 0 else layers[layer_index].mu_r
    azimuth, dip = _orientation(receiver.component)
    rec = [receiver.x, receiver.y, rec_z, azimuth, dip]
    mrec, scale, _ = _receiver_mode_layered(receiver, receiver_mu_r)
    n_total = len(layers) + 1
    rho = np.empty(n_total, dtype=float)
    rho[0] = 1.0 / numerics.air_conductivity_s_per_m
    rho[1:] = [1.0 / layer.model.sigma_inf for layer in layers]
    mu_r = np.asarray([1.0] + [layer.mu_r for layer in layers], dtype=float)
    zeros = np.zeros(n_total, dtype=float)
    res = {
        "res": rho,
        "func_eta": _eta_hook_layered_isotropic_legacy(
            [layer.model for layer in layers], numerics.air_conductivity_s_per_m
        ),
    }
    method, htarg = _hankel_args(config, hankel)
    em = empymod.bipole(
        src=source,
        rec=rec,
        depth=depth,
        res=res,
        freqtime=frequencies,
        signal=None,
        aniso=np.ones(n_total),
        epermH=zeros,
        epermV=zeros,
        mpermH=mu_r,
        mpermV=mu_r,
        msrc=False,
        srcpts=numerics.source_quadrature_points,
        mrec=mrec,
        recpts=1,
        strength=config.source.current_a,
        ht=method,
        htarg=htarg,
        xdirect=False,
        verb=numerics.verbosity,
        squeeze=True,
    )
    return np.asarray(em).reshape(-1) * scale


def check_isotropic_limit(
    config: SimulationConfig,
    frequencies_hz: np.ndarray | None = None,
) -> dict:
    """Check the isotropic limit of the VTI solver."""
    if frequencies_hz is None:
        frequencies_hz = np.geomspace(1.0e-2, 1.0e4, 13)
    isotropic = isotropic_limit_config(config)
    absolute = 0.0
    relative = 0.0
    for index in range(len(isotropic.receivers)):
        current = frequency_response(isotropic, frequencies_hz, index)
        reference = legacy_isotropic_frequency_response(isotropic, frequencies_hz, index)
        difference = np.abs(current - reference)
        absolute = max(absolute, float(np.max(difference)))
        floor = np.maximum(np.abs(reference), 1.0e-300)
        relative = max(relative, float(np.max(difference / floor)))
    return {
        "frequencies_hz": np.asarray(frequencies_hz, dtype=float).tolist(),
        "receiver_count": len(isotropic.receivers),
        "max_absolute": absolute,
        "max_relative": relative,
        "exact_array_equality": absolute == 0.0,
        "status": "PASS" if absolute == 0.0 else "FAIL",
    }
