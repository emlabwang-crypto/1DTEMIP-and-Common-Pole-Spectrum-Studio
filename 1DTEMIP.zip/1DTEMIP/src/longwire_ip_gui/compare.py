"""3D comparison helpers."""
from __future__ import annotations
from pathlib import Path
import re
import numpy as np


def read_numeric_response(path: str | Path, time_column: int = -2,
                          value_column: int = -1) -> tuple[np.ndarray, np.ndarray]:
    rows: list[list[float]] = []
    for raw in Path(path).read_text(encoding="utf-8", errors="replace").splitlines():
        s = raw.strip()
        if not s or s.startswith(("#", "!", "%", ";")):
            continue
        vals = []
        for tok in re.split(r"[\s,;]+", s):
            try: vals.append(float(tok.replace("D", "E").replace("d", "e")))
            except ValueError: pass
        if len(vals) >= 2: rows.append(vals)
    if not rows:
        raise ValueError("No numeric rows found in file")
    t, v = [], []
    for row in rows:
        try:
            t.append(row[time_column]); v.append(row[value_column])
        except IndexError as exc:
            raise ValueError("Selected column exceeds number of data columns") from exc
    return np.asarray(t), np.asarray(v)


def metrics(reference: np.ndarray, numerical: np.ndarray, floor_fraction: float = 1e-8) -> dict:
    r = np.asarray(reference); n = np.asarray(numerical)
    if r.shape != n.shape: raise ValueError("Array lengths do not match")
    d = n-r
    scale = max(float(np.max(np.abs(r))), np.finfo(float).tiny)
    denom = np.maximum(np.abs(r), floor_fraction*scale)
    rel = np.abs(d)/denom
    return {
        "max_abs_error": float(np.max(np.abs(d))),
        "rms_abs_error": float(np.sqrt(np.mean(d*d))),
        "max_relative_error_with_floor": float(np.max(rel)),
        "rms_relative_error_with_floor": float(np.sqrt(np.mean(rel*rel))),
        "normalized_l2_error": float(np.linalg.norm(d)/max(np.linalg.norm(r), np.finfo(float).tiny)),
        "sign_mismatch_count": int(np.count_nonzero(np.signbit(r) != np.signbit(n))),
    }
