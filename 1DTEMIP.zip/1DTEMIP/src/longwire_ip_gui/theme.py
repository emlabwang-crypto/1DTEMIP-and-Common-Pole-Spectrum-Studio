"""A compact, dependency-free Qt theme system for the modelling workspace."""
from __future__ import annotations

THEMES = {'vscode_dark_modern': {'name': 'VS Code Dark Modern',
                        'background': '#181818',
                        'surface': '#1f1f1f',
                        'surface2': '#252526',
                        'text': '#d4d4d4',
                        'muted': '#a9a9a9',
                        'border': '#3c3c3c',
                        'accent': '#0078d4',
                        'hover': '#1769b2',
                        'selected': '#264f78',
                        'danger': '#f14c4c',
                        'grid': '#454545',
                        'plot': '#4fc1ff',
                        'negative': '#f9a66c',
                        'secondary_plot': '#9cdcfe'},
 'vscode_dark': {'name': 'VS Code Dark+',
                 'background': '#1e1e1e',
                 'surface': '#252526',
                 'surface2': '#2d2d30',
                 'text': '#d4d4d4',
                 'muted': '#aaaaaa',
                 'border': '#3e3e42',
                 'accent': '#0e639c',
                 'hover': '#1177bb',
                 'selected': '#264f78',
                 'danger': '#f14c4c',
                 'grid': '#454545',
                 'plot': '#4fc1ff',
                 'negative': '#ce9178',
                 'secondary_plot': '#b8c8db'},
 'vscode_light_modern': {'name': 'VS Code Light Modern',
                         'background': '#f8f8f8',
                         'surface': '#ffffff',
                         'surface2': '#f3f3f3',
                         'text': '#1f1f1f',
                         'muted': '#616161',
                         'border': '#d4d4d4',
                         'accent': '#005fb8',
                         'hover': '#0078d4',
                         'selected': '#d8ebff',
                         'danger': '#c72e0f',
                         'grid': '#dcdcdc',
                         'plot': '#005fb8',
                         'negative': '#a45200',
                         'secondary_plot': '#637085'},
 'vscode_light': {'name': 'VS Code Light+',
                  'background': '#f3f3f3',
                  'surface': '#ffffff',
                  'surface2': '#f8f8f8',
                  'text': '#242424',
                  'muted': '#666666',
                  'border': '#dedede',
                  'accent': '#007acc',
                  'hover': '#0062a3',
                  'selected': '#dceeff',
                  'danger': '#c34343',
                  'grid': '#dedede',
                  'plot': '#006cbb',
                  'negative': '#bf6c31',
                  'secondary_plot': '#707070'},
 'vscode_high_contrast': {'name': 'VS Code High Contrast',
                          'background': '#000000',
                          'surface': '#0b0b0b',
                          'surface2': '#171717',
                          'text': '#ffffff',
                          'muted': '#dedede',
                          'border': '#858585',
                          'accent': '#1aebff',
                          'hover': '#00bcd4',
                          'selected': '#043c50',
                          'danger': '#ff6978',
                          'grid': '#3e3e3e',
                          'plot': '#4ac9ff',
                          'negative': '#ffb86c',
                          'secondary_plot': '#cbcbcb'},
 'vscode_monokai': {'name': 'VS Code Monokai',
                    'background': '#272822',
                    'surface': '#30312b',
                    'surface2': '#383932',
                    'text': '#f8f8f2',
                    'muted': '#c1c3b8',
                    'border': '#55564e',
                    'accent': '#a6e22e',
                    'hover': '#8fcb28',
                    'selected': '#3a4b2b',
                    'danger': '#f92672',
                    'grid': '#56574d',
                    'plot': '#66d9ef',
                    'negative': '#fd971f',
                    'secondary_plot': '#ae81ff'},
 'vscode_solarized_dark': {'name': 'VS Code Solarized Dark',
                           'background': '#002b36',
                           'surface': '#073642',
                           'surface2': '#0a3c48',
                           'text': '#93a1a1',
                           'muted': '#839496',
                           'border': '#27505a',
                           'accent': '#268bd2',
                           'hover': '#2aa6ed',
                           'selected': '#15516b',
                           'danger': '#dc322f',
                           'grid': '#1a5360',
                           'plot': '#2aa198',
                           'negative': '#cb4b16',
                           'secondary_plot': '#6c9caa'},
 'vscode_solarized_light': {'name': 'VS Code Solarized Light',
                            'background': '#eee8d5',
                            'surface': '#fdf6e3',
                            'surface2': '#f5efde',
                            'text': '#586e75',
                            'muted': '#6e8184',
                            'border': '#d4cbb5',
                            'accent': '#268bd2',
                            'hover': '#146baf',
                            'selected': '#e2e6d7',
                            'danger': '#dc322f',
                            'grid': '#dcd4c1',
                            'plot': '#268bd2',
                            'negative': '#cb4b16',
                            'secondary_plot': '#859900'},
 'vscode_quiet_light': {'name': 'VS Code Quiet Light',
                        'background': '#f4f7f8',
                        'surface': '#ffffff',
                        'surface2': '#f0f5f6',
                        'text': '#334451',
                        'muted': '#647983',
                        'border': '#d8e4e7',
                        'accent': '#397b8e',
                        'hover': '#28667a',
                        'selected': '#dff0f0',
                        'danger': '#b95e5d',
                        'grid': '#d7e7e7',
                        'plot': '#26859c',
                        'negative': '#c07b4b',
                        'secondary_plot': '#768a90'}}

def qss(theme: str) -> str:
    c = THEMES.get(theme, THEMES["vscode_dark_modern"])
    return f"""
    QMainWindow, QDialog, QWidget {{ background:{c['background']}; color:{c['text']}; }}
    QMenuBar, QMenu, QStatusBar {{ background:{c['surface']}; border:0; color:{c['text']}; }}
    QMenuBar::item:selected, QMenu::item:selected {{ background:{c['selected']}; }}
    QFrame[surface="true"], QGroupBox, QTabWidget::pane {{
        background:{c['surface']}; border:1px solid {c['border']}; border-radius:7px;
    }}
    QFrame[hint="true"] {{ background:{c['surface2']}; border:1px solid {c['border']}; border-radius:6px; }}
    QFrame[sidebar="true"] {{ background:{c['surface']}; border-right:1px solid {c['border']}; }}
    QGroupBox {{ margin-top:13px; padding:11px 9px 8px 9px; font-weight:600; }}
    QGroupBox::title {{ subcontrol-origin:margin; left:12px; padding:1px 6px; color:{c['muted']}; }}
    QLabel[title="true"] {{ font-size:22px; font-weight:700; color:{c['text']}; }}
    QLabel[subtitle="true"] {{ color:{c['muted']}; }}
    QLabel[badge="true"] {{ background:{c['selected']}; color:{c['text']}; border-radius:5px; padding:6px 10px; }}
    QLabel[section="true"] {{ font-size:15px; font-weight:700; color:{c['muted']}; }}
    QTabWidget::pane {{ top:-1px; }}
    QTabBar::tab {{ background:{c['surface2']}; border:1px solid {c['border']};
        padding:10px 14px; margin-right:2px; border-top-left-radius:5px; border-top-right-radius:5px; }}
    QTabBar::tab:selected {{ background:{c['surface']}; border-bottom:1px solid {c['surface']};
        color:{c['accent']}; font-weight:600; }}
    QLineEdit, QDoubleSpinBox, QSpinBox, QComboBox, QPlainTextEdit, QTableWidget, QTreeWidget {{
        color:{c['text']}; background:{c['surface']}; border:1px solid {c['border']};
        border-radius:5px; padding:6px 8px; selection-background-color:{c['selected']};
        selection-color:{c['text']}; }}
    QTableWidget, QTreeWidget {{ alternate-background-color:{c['surface2']}; gridline-color:{c['border']}; padding:0; }}
    QTreeWidget {{ border:0; background:{c['surface']}; }}
    QTreeWidget::item {{ padding:9px 7px; border-radius:3px; }}
    QTreeWidget::item:selected {{ color:{c['accent']}; background:{c['selected']}; }}
    QHeaderView::section {{ background:{c['surface2']}; color:{c['muted']};
        border:0; border-right:1px solid {c['border']}; border-bottom:1px solid {c['border']};
        padding:9px; font-weight:600; }}
    QLineEdit:focus, QDoubleSpinBox:focus, QSpinBox:focus, QComboBox:focus, QPlainTextEdit:focus {{ border:1px solid {c['accent']}; }}
    QPushButton {{ color:{'#111111' if theme in ('vscode_monokai', 'vscode_high_contrast') else '#ffffff'}; background:{c['accent']}; border:1px solid {c['accent']};
        border-radius:5px; padding:9px 14px; font-weight:600; min-height:20px; }}
    QPushButton:hover {{ background:{c['hover']}; }}
    QPushButton:disabled {{ background:{c['surface2']}; color:{c['muted']}; border-color:{c['border']}; }}
    QPushButton[secondary="true"] {{ background:{c['surface2']}; color:{c['text']}; border-color:{c['border']}; }}
    QPushButton[secondary="true"]:hover {{ background:{c['selected']}; }}
    QPushButton[danger="true"] {{ background:{c['danger']}; border-color:{c['danger']}; }}
    QProgressBar {{ background:{c['surface2']}; border:1px solid {c['border']}; border-radius:4px; text-align:center; min-height:20px; }}
    QProgressBar::chunk {{ background:{c['accent']}; border-radius:3px; }}
    QSplitter::handle {{ background:{c['border']}; }}
    QScrollBar:vertical, QScrollBar:horizontal {{ background:{c['surface2']}; }}
    QScrollBar::handle:vertical, QScrollBar::handle:horizontal {{ background:{c['border']}; border-radius:4px; min-height:24px; min-width:24px; }}
    QCheckBox {{ spacing:9px; }}
    QComboBox::drop-down {{ border:0; width:24px; }}
    QToolTip {{ color:{c['text']}; background:{c['surface2']}; border:1px solid {c['border']}; padding:5px; }}
    """


def style_axes(ax, palette: dict) -> None:
    fig = ax.figure
    fig.set_facecolor(palette['surface'])
    ax.set_facecolor(palette['surface'])
    ax.title.set_color(palette['text'])
    ax.xaxis.label.set_color(palette['text'])
    ax.yaxis.label.set_color(palette['text'])
    from matplotlib import rcParams
    ax.tick_params(axis='both', colors=palette['muted'], labelsize=rcParams['xtick.labelsize'])
    ax.title.set_fontsize(rcParams['axes.titlesize'])
    ax.xaxis.label.set_fontsize(rcParams['axes.labelsize'])
    ax.yaxis.label.set_fontsize(rcParams['axes.labelsize'])
    for spine in ax.spines.values():
        spine.set_color(palette['border'])
    ax.grid(True, which='both', color=palette['grid'], alpha=0.45, linewidth=0.7)
    legend = ax.get_legend()
    if legend is not None:
        legend.get_frame().set_facecolor(palette['surface'])
        legend.get_frame().set_edgecolor(palette['border'])
        for label in legend.get_texts():
            label.set_color(palette['text'])
            label.set_fontsize(rcParams['legend.fontsize'])
