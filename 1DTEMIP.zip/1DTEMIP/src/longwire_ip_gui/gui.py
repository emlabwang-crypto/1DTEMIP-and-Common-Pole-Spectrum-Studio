"""Modern PySide6 GUI for finite-wire layered-earth IP switch-off modelling."""
from __future__ import annotations

import copy
import traceback
from pathlib import Path

import numpy as np
from matplotlib import rcParams
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from PySide6.QtCore import QEvent, QObject, QSettings, QThread, QTimer, Qt, Signal, Slot
from PySide6.QtGui import QAction, QFont, QFontDatabase
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QComboBox,
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .compare import metrics, read_numeric_response
from .config import (
    EarthLayer,
    Numerics,
    Receiver,
    SimulationConfig,
    Source,
    load_config,
    save_config,
)
from .models import GemtipPhase, IPModel, MgemtipPhaseInput
from .solver import (
    SimulationResult,
    anisotropy_summary,
    check_isotropic_limit,
    homogeneous_equivalent,
    isotropic_limit_config,
    solve_stepoff,
    write_results,
)
from .timeio import read_observation_times
from .theme import THEMES, qss, style_axes
from .plotting import plot_signed_log_response

APP_TITLE = "1D TEM-IP Studio"
MODEL_KINDS = [
    "NONE",
    "DEBYE",
    "COLE_COLE",
    "GEMTIP",
    "MGEMTIP",
]
FONT_CANDIDATES = [
    "Segoe UI", "SF Pro Text", "Inter", "Helvetica Neue", "Arial", "DejaVu Sans",
]

APP_QSS = qss("vscode_dark_modern")


def configure_fonts(app: QApplication) -> str:
    installed = set(QFontDatabase.families())
    selected = next((name for name in FONT_CANDIDATES if name in installed), "Sans Serif")
    app.setFont(QFont(selected, 12))
    rcParams["font.family"] = "sans-serif"
    rcParams["font.sans-serif"] = FONT_CANDIDATES
    rcParams["axes.unicode_minus"] = False
    rcParams["font.size"] = 11
    rcParams["axes.titlesize"] = 12
    rcParams["axes.labelsize"] = 11
    rcParams["xtick.labelsize"] = 10
    rcParams["ytick.labelsize"] = 10
    rcParams["legend.fontsize"] = 10
    rcParams["figure.dpi"] = 110
    rcParams["savefig.dpi"] = 600
    return selected


def secondary_button(text: str) -> QPushButton:
    button = QPushButton(text)
    button.setProperty("secondary", True)
    return button


def danger_button(text: str) -> QPushButton:
    button = QPushButton(text)
    button.setProperty("danger", True)
    return button


def model_brief(model: IPModel) -> str:
    kind = model.kind
    if kind == "NONE":
        return "No IP"
    if kind == "DEBYE":
        m, tau, _, _ = model.legacy
        return f"m={m:.3g}, τ={tau:.3g}s"
    if kind == "COLE_COLE":
        m, tau, c, _ = model.legacy
        return f"m={m:.3g}, τ={tau:.3g}s, c={c:.3g}"
    if kind == "GEMTIP":
        return f"{len(model.gemtip_phases)} phase GEMTIP"
    if kind == "MGEMTIP":
        return f"{len(model.mgemtip_input)} phase spherical MGEMTIP"
    return kind


class SciSpinBox(QDoubleSpinBox):
    """Double spin box with stable scientific notation and unrestricted typing."""

    def __init__(
        self,
        value: float,
        minimum: float = -1.0e100,
        maximum: float = 1.0e100,
        decimals: int = 16,
        parent: QWidget | None = None,
    ):
        super().__init__(parent)
        self.setDecimals(decimals)
        self.setRange(minimum, maximum)
        self.setKeyboardTracking(False)
        self.setAccelerated(True)
        self.setValue(value)
        self.setMinimumWidth(125)

    def textFromValue(self, value: float) -> str:  # noqa: N802
        return f"{value:.12g}"

    def valueFromText(self, text: str) -> float:  # noqa: N802
        return float(text.strip().replace(",", ""))

    def validate(self, text: str, position: int):  # noqa: N802
        stripped = text.strip()
        if stripped in {"", "+", "-", ".", "+.", "-."}:
            from PySide6.QtGui import QValidator
            return QValidator.Intermediate, text, position
        try:
            float(stripped)
        except ValueError:
            from PySide6.QtGui import QValidator
            return QValidator.Intermediate, text, position
        from PySide6.QtGui import QValidator
        return QValidator.Acceptable, text, position


class SelectRowFilter(QObject):
    def __init__(self, table: QTableWidget, row: int, parent: QObject | None = None):
        super().__init__(parent)
        self.table = table
        self.row = row

    def eventFilter(self, watched, event):  # noqa: N802
        if event.type() in {QEvent.MouseButtonPress, QEvent.FocusIn}:
            self.table.selectRow(self.row)
            self.table.setCurrentCell(self.row, 0)
        return False


class ResponseCanvas(FigureCanvas):
    def __init__(self):
        figure = Figure(figsize=(9.5, 5.4), constrained_layout=True, facecolor="white")
        grid = figure.add_gridspec(1, 2, width_ratios=[3.3, 1.2])
        self.response_ax = figure.add_subplot(grid[0, 0])
        self.model_ax = figure.add_subplot(grid[0, 1])
        super().__init__(figure)
        self.figure = figure


class LayerProfileCanvas(FigureCanvas):
    def __init__(self):
        figure = Figure(figsize=(4.5, 5.2), constrained_layout=True)
        self.axes = figure.add_subplot(111)
        super().__init__(figure)
        self.figure = figure
        self.theme_spec = THEMES["vscode_dark_modern"]

    def draw_layers(self, layers: list[EarthLayer], message: str = "") -> None:
        ax = self.axes
        ax.clear()
        if not layers:
            ax.text(0.5, 0.5, message or "No layers configured", ha="center", va="center")
            style_axes(ax, self.theme_spec)
            self.draw_idle()
            return
        finite_total = sum(float(x.thickness_m or 0.0) for x in layers[:-1])
        extension = max(100.0, finite_total * 0.35, 50.0)
        tops: list[float] = []
        bottoms: list[float] = []
        depth = 0.0
        for layer in layers[:-1]:
            tops.append(depth)
            depth += float(layer.thickness_m)
            bottoms.append(depth)
        tops.append(depth)
        bottoms.append(depth + extension)
        for index, layer in enumerate(layers):
            layer.finalize()
            rho_h = 1.0 / layer.model.sigma_inf
            rho_v = 1.0 / layer.vertical_model.sigma_inf
            ax.plot(
                [rho_h, rho_h], [tops[index], bottoms[index]], linewidth=4.5,
                solid_capstyle="butt", label="ρH∞" if index == 0 else None,
            )
            ax.plot(
                [rho_v, rho_v], [tops[index], bottoms[index]], linewidth=2.5,
                linestyle="--", label="ρV∞" if index == 0 else None,
            )
            ax.text(
                max(rho_h, rho_v) * 1.08,
                0.5 * (tops[index] + bottoms[index]),
                layer.name,
                fontsize=10,
                va="center",
            )
            if index < len(layers) - 1:
                ax.axhline(bottoms[index], linewidth=0.8, alpha=0.35)
        ax.set_xscale("log")
        ax.set_ylim(bottoms[-1], 0.0)
        ax.set_xlabel("High-frequency resistivity (Ω·m)")
        ax.set_ylabel("Depth z (m)")
        ax.set_title("VTI layering · Horizontal H / Vertical V")
        ax.grid(True, which="both", alpha=0.22)
        ax.legend(loc="best", fontsize=10)
        if message:
            ax.text(0.02, 0.02, message, transform=ax.transAxes, fontsize=10, color=self.theme_spec["accent"])
        style_axes(ax, self.theme_spec)
        self.draw_idle()


class PhaseDialog(QDialog):
    def __init__(
        self,
        kind: str,
        gemtip: list[GemtipPhase],
        mgemtip: list[MgemtipPhaseInput],
        parent: QWidget | None = None,
    ):
        super().__init__(parent)
        self.kind = kind
        self.setWindowTitle(f"{kind} Multiphase parameters")
        self.resize(980 if kind == "GEMTIP" else 700, 430)
        root = QVBoxLayout(self)
        info = QLabel(
            "GEMTIP: f, τ, C, γx, γy, γz, sx, sy, sz per row."
            if kind == "GEMTIP"
            else "MGEMTIP: volume fraction, inclusion conductivity, radius and surface factor per row."
        )
        info.setWordWrap(True)
        root.addWidget(info)
        columns = 9 if kind == "GEMTIP" else 4
        self.table = QTableWidget(0, columns)
        if kind == "GEMTIP":
            self.table.setHorizontalHeaderLabels(
                ["f", "τ(s)", "C", "γx", "γy", "γz", "sx", "sy", "sz"]
            )
        else:
            self.table.setHorizontalHeaderLabels(
                ["f", "Inclusion σ (S/m)", "Radius (m)", "Surface factor"]
            )
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        root.addWidget(self.table, 1)
        actions = QHBoxLayout()
        add = QPushButton("Add phase")
        remove = danger_button("Remove selected phase")
        sphere = secondary_button("Set spherical GEMTIP")
        add.clicked.connect(self.add_row)
        remove.clicked.connect(self.remove_rows)
        sphere.clicked.connect(self.set_sphere)
        actions.addWidget(add)
        actions.addWidget(remove)
        if kind == "GEMTIP":
            actions.addWidget(sphere)
        actions.addStretch()
        root.addLayout(actions)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._accept_checked)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

        if kind == "GEMTIP":
            phases = gemtip or [GemtipPhase(0.05, 0.1, 0.7)]
            for phase in phases:
                self._append_values(
                    [
                        phase.fraction,
                        phase.tau,
                        phase.exponent,
                        *phase.gamma,
                        *phase.structural_factor,
                    ]
                )
        else:
            phases = mgemtip or [MgemtipPhaseInput(0.03, 5.0, 1.0e-3, 2.0)]
            for phase in phases:
                self._append_values(
                    [
                        phase.fraction,
                        phase.inclusion_sigma,
                        phase.radius,
                        phase.surface_factor,
                    ]
                )

    def _append_values(self, values: list[float]) -> None:
        row = self.table.rowCount()
        self.table.insertRow(row)
        for column, value in enumerate(values):
            item = QTableWidgetItem(f"{value:.12g}")
            item.setTextAlignment(Qt.AlignCenter)
            self.table.setItem(row, column, item)

    def add_row(self) -> None:
        if self.kind == "GEMTIP":
            self._append_values([0.05, 0.1, 0.7, 1 / 3, 1 / 3, 1 / 3, 1, 1, 1])
        else:
            self._append_values([0.03, 5.0, 1.0e-3, 2.0])
        self.table.selectRow(self.table.rowCount() - 1)

    def remove_rows(self) -> None:
        rows = sorted({index.row() for index in self.table.selectedIndexes()}, reverse=True)
        if not rows:
            QMessageBox.information(self, "Select", "Select the phase to remove.")
            return
        for row in rows:
            self.table.removeRow(row)

    def set_sphere(self) -> None:
        rows = sorted({index.row() for index in self.table.selectedIndexes()})
        if not rows:
            rows = list(range(self.table.rowCount()))
        for row in rows:
            for column, value in zip(range(3, 9), [1 / 3, 1 / 3, 1 / 3, 1, 1, 1]):
                self.table.setItem(row, column, QTableWidgetItem(f"{value:.12g}"))

    def values(self) -> list[list[float]]:
        output: list[list[float]] = []
        for row in range(self.table.rowCount()):
            current: list[float] = []
            for column in range(self.table.columnCount()):
                item = self.table.item(row, column)
                if item is None or not item.text().strip():
                    raise ValueError(f"Layer or row {row + 1} row, column {column + 1} is empty")
                current.append(float(item.text()))
            output.append(current)
        if not output:
            raise ValueError("At least one IP phase is required")
        return output

    def _accept_checked(self) -> None:
        try:
            values = self.values()
            model = IPModel(self.kind, 0.01)
            if self.kind == "GEMTIP":
                for value in values:
                    model.gemtip_phases.append(
                        GemtipPhase(value[0], value[1], value[2], tuple(value[3:6]), tuple(value[6:9]))
                    )
            else:
                for value in values:
                    model.mgemtip_input.append(MgemtipPhaseInput(*value))
            model.finalize()
        except Exception as exc:
            QMessageBox.critical(self, "Invalid parameters", str(exc))
            return
        self.accept()

    def result_phases(self):
        values = self.values()
        if self.kind == "GEMTIP":
            return (
                [
                    GemtipPhase(x[0], x[1], x[2], tuple(x[3:6]), tuple(x[6:9]))
                    for x in values
                ],
                [],
            )
        return ([], [MgemtipPhaseInput(*x) for x in values])


class ScalarModelEditor(QWidget):
    """Compact editor for one scalar constitutive spectrum."""

    changed = Signal()

    def __init__(self, model: IPModel, title: str, parent: QWidget | None = None):
        super().__init__(parent)
        self._gemtip: list[GemtipPhase] = []
        self._mgemtip: list[MgemtipPhaseInput] = []
        root = QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        title_label = QLabel(title)
        title_label.setProperty("title", True)
        root.addWidget(title_label)
        form = QFormLayout()
        self.kind = QComboBox()
        self.kind.addItems(MODEL_KINDS)
        self.sigma = SciSpinBox(0.01, 1.0e-12, 1.0e6)
        self.rho = SciSpinBox(100.0, 1.0e-6, 1.0e12)
        self.m = SciSpinBox(0.1, 0.0, 0.999999999)
        self.tau = SciSpinBox(0.1, 1.0e-12, 1.0e12)
        self.alpha = SciSpinBox(0.7, 1.0e-8, 1.0)
        self.sigma0 = QLabel("—")
        self.sigma0.setProperty("badge", True)
        self.details = secondary_button("Edit multiphase parameters…")
        form.addRow("IP model", self.kind)
        form.addRow("σ∞ (S/m)", self.sigma)
        form.addRow("ρ∞ (Ω·m)", self.rho)
        form.addRow("Chargeability m", self.m)
        form.addRow("Time constant τ (s)", self.tau)
        form.addRow("Cole–Cole exponent c", self.alpha)
        form.addRow("σ0 (S/m)", self.sigma0)
        form.addRow("Complex model", self.details)
        root.addLayout(form)
        note = QLabel("Press Enter or move focus to apply changes.")
        note.setProperty("subtitle", True)
        root.addWidget(note)
        root.addStretch()

        self.kind.currentTextChanged.connect(self._kind_changed)
        self.sigma.valueChanged.connect(self._sigma_changed)
        self.rho.valueChanged.connect(self._rho_changed)
        for widget in [self.m, self.tau, self.alpha]:
            widget.valueChanged.connect(self._refresh)
        self.details.clicked.connect(self._edit_phases)
        self.set_model(model)

    def set_model(self, model: IPModel) -> None:
        model = copy.deepcopy(model).finalize()
        for widget in [self.kind, self.sigma, self.rho, self.m, self.tau, self.alpha]:
            widget.blockSignals(True)
        self.kind.setCurrentText(model.kind)
        self.sigma.setValue(model.sigma_inf)
        self.rho.setValue(1.0 / model.sigma_inf)
        m, tau, alpha, _ = model.legacy
        self.m.setValue(m if model.kind != "NONE" else 0.0)
        self.tau.setValue(tau if tau > 0 else 0.1)
        self.alpha.setValue(alpha if alpha > 0 else 1.0)
        self._gemtip = copy.deepcopy(model.gemtip_phases)
        self._mgemtip = copy.deepcopy(model.mgemtip_input)
        for widget in [self.kind, self.sigma, self.rho, self.m, self.tau, self.alpha]:
            widget.blockSignals(False)
        self._kind_changed(emit=False)

    def _legacy(self, kind: str) -> tuple[float, float, float, float]:
        m = float(self.m.value())
        tau = float(self.tau.value())
        c = float(self.alpha.value())
        if kind == "NONE":
            return 0.0, 0.0, 0.0, 0.0
        if kind == "DEBYE":
            return m, tau, 1.0, 1.0
        if kind == "COLE_COLE":
            return m, tau, c, 1.0
        return 0.0, 0.0, 0.0, 0.0

    def model(self) -> IPModel:
        kind = self.kind.currentText()
        model = IPModel(kind, float(self.sigma.value()), legacy=self._legacy(kind))
        if kind == "GEMTIP":
            model.gemtip_phases = copy.deepcopy(
                self._gemtip or [GemtipPhase(0.05, 0.1, 0.7)]
            )
        elif kind == "MGEMTIP":
            model.mgemtip_input = copy.deepcopy(
                self._mgemtip or [MgemtipPhaseInput(0.03, 5.0, 1.0e-3, 2.0)]
            )
        return model.finalize()

    def _kind_changed(self, _value: str = "", emit: bool = True) -> None:
        kind = self.kind.currentText()
        states = {
            "NONE": (False, False, False),
            "DEBYE": (True, True, False),
            "COLE_COLE": (True, True, True),
            "GEMTIP": (False, False, False),
            "MGEMTIP": (False, False, False),
        }[kind]
        for widget, enabled in zip([self.m, self.tau, self.alpha], states):
            widget.setEnabled(enabled)
        self.details.setEnabled(kind in {"GEMTIP", "MGEMTIP"})
        self.details.setText("Edit multiphase parameters…" if self.details.isEnabled() else "Not required")
        if kind == "DEBYE":
            self.alpha.setValue(1.0)
        self._refresh(emit=emit)

    def _sigma_changed(self, *_args) -> None:
        sigma = float(self.sigma.value())
        if sigma > 0:
            self.rho.blockSignals(True)
            self.rho.setValue(1.0 / sigma)
            self.rho.blockSignals(False)
        self._refresh()

    def _rho_changed(self, *_args) -> None:
        rho = float(self.rho.value())
        if rho > 0:
            self.sigma.blockSignals(True)
            self.sigma.setValue(1.0 / rho)
            self.sigma.blockSignals(False)
        self._refresh()

    def _refresh(self, *_args, emit: bool = True) -> None:
        try:
            model = self.model()
            self.sigma0.setText(f"{model.sigma0:.10g}")
            self.sigma0.setStyleSheet("")
        except Exception as exc:
            self.sigma0.setText("Invalid parameters")
            self.sigma0.setStyleSheet("color:#d43f4b;font-weight:700;")
            self.sigma0.setToolTip(str(exc))
        if emit:
            self.changed.emit()

    def _edit_phases(self) -> None:
        kind = self.kind.currentText()
        if kind not in {"GEMTIP", "MGEMTIP"}:
            return
        dialog = PhaseDialog(kind, self._gemtip, self._mgemtip, self)
        if dialog.exec() == QDialog.Accepted:
            self._gemtip, self._mgemtip = dialog.result_phases()
            self._refresh()


class VtiLayerEditorDialog(QDialog):
    """Edit one layer as exact 1-D VTI: H=(x,y), V=z."""

    def __init__(self, layer: EarthLayer, is_halfspace: bool, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Edit VTI layer")
        self.resize(900, 650)
        layer = copy.deepcopy(layer).finalize()
        root = QVBoxLayout(self)

        header = QGroupBox("Layer properties")
        form = QGridLayout(header)
        self.name = QLineEdit(layer.name)
        self.mu = SciSpinBox(layer.mu_r, 1.0e-6, 1.0e6)
        form.addWidget(QLabel("Name"), 0, 0)
        form.addWidget(self.name, 0, 1)
        form.addWidget(QLabel("Relative permeability μr"), 0, 2)
        form.addWidget(self.mu, 0, 3)
        if is_halfspace:
            self.thickness = None
            half = QLabel("∞ (half-space)")
            half.setProperty("badge", True)
            form.addWidget(QLabel("Thickness"), 1, 0)
            form.addWidget(half, 1, 1)
        else:
            self.thickness = SciSpinBox(float(layer.thickness_m), 1.0e-6, 1.0e12)
            form.addWidget(QLabel("Thickness (m)"), 1, 0)
            form.addWidget(self.thickness, 1, 1)
        self.isotropic = QCheckBox("Isotropic: V follows H exactly")
        self.isotropic.setChecked(layer.is_electrically_isotropic)
        form.addWidget(self.isotropic, 1, 2, 1, 2)
        root.addWidget(header)

        toolbar = QHBoxLayout()
        copy_hv = QPushButton("H → V")
        copy_vh = secondary_button("V → H")
        swap = secondary_button("Swap H / V")
        copy_hv.clicked.connect(self.copy_h_to_v)
        copy_vh.clicked.connect(self.copy_v_to_h)
        swap.clicked.connect(self.swap_models)
        toolbar.addWidget(copy_hv)
        toolbar.addWidget(copy_vh)
        toolbar.addWidget(swap)
        toolbar.addStretch()
        root.addLayout(toolbar)

        self.tabs = QTabWidget()
        self.horizontal = ScalarModelEditor(layer.model, "Horizontal H: σx = σy", self)
        self.vertical = ScalarModelEditor(layer.vertical_model, "Vertical V: σz", self)
        self.tabs.addTab(self.horizontal, "Horizontal H")
        self.tabs.addTab(self.vertical, "Vertical V")
        root.addWidget(self.tabs, 1)

        info = QLabel(
            "Applicable to horizontally layered VTI (σx=σy=σH, σz=σV), without rotated principal axes. "
            "H=V selects the isotropic solver."
        )
        info.setWordWrap(True)
        info.setProperty("subtitle", True)
        root.addWidget(info)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("Save layer")
        buttons.button(QDialogButtonBox.Cancel).setText("Cancel")
        buttons.accepted.connect(self._accept_checked)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

        self.horizontal.kind.currentTextChanged.connect(self._sync_kind)
        self.horizontal.changed.connect(self._follow_horizontal_if_isotropic)
        self.isotropic.toggled.connect(self._isotropic_toggled)
        self._isotropic_toggled(self.isotropic.isChecked())

    def _follow_horizontal_if_isotropic(self) -> None:
        if self.isotropic.isChecked():
            try:
                self.vertical.set_model(self.horizontal.model())
            except Exception:
                pass

    def _sync_kind(self, value: str) -> None:
        if self.vertical.kind.currentText() != value:
            self.vertical.kind.setCurrentText(value)
        if value == "MGEMTIP":
            self.isotropic.setChecked(True)
            self.isotropic.setToolTip("MGEMTIP currently supports spherical isotropic inclusions only")
        else:
            self.isotropic.setToolTip("")

    def _isotropic_toggled(self, checked: bool) -> None:
        if checked:
            self.copy_h_to_v()
        self.vertical.setEnabled(not checked)
        # V always uses the same constitutive family as H; only native
        # parameters and conductivity are independent in VTI mode.
        self.vertical.kind.setEnabled(False)
        self.tabs.setTabText(1, "Vertical V (linked to H)" if checked else "Vertical V")

    def copy_h_to_v(self) -> None:
        try:
            self.vertical.set_model(self.horizontal.model())
        except Exception as exc:
            QMessageBox.critical(self, "Copy failed", str(exc))

    def copy_v_to_h(self) -> None:
        try:
            self.horizontal.set_model(self.vertical.model())
        except Exception as exc:
            QMessageBox.critical(self, "Copy failed", str(exc))

    def swap_models(self) -> None:
        try:
            h = self.horizontal.model()
            v = self.vertical.model()
            self.horizontal.set_model(v)
            self.vertical.set_model(h)
        except Exception as exc:
            QMessageBox.critical(self, "Swap failed", str(exc))

    def result_layer(self) -> EarthLayer:
        h = self.horizontal.model()
        v = copy.deepcopy(h) if self.isotropic.isChecked() else self.vertical.model()
        if h.kind != v.kind:
            raise ValueError("H and V must use the same IP model family")
        if h.kind == "MGEMTIP" and h.metadata() != v.metadata():
            raise ValueError("MGEMTIP is restricted to spherical isotropic media; set V=H")
        thickness = None if self.thickness is None else float(self.thickness.value())
        return EarthLayer(
            self.name.text().strip() or "Layer",
            thickness,
            h,
            float(self.mu.value()),
            v,
        ).finalize()

    def _accept_checked(self) -> None:
        try:
            self.result_layer()
        except Exception as exc:
            QMessageBox.critical(self, "Invalid parameters", str(exc))
            return
        self.accept()


class LayerTable(QWidget):
    changed = Signal()
    message = Signal(str)

    HEADERS = [
        "#", "Name", "Thickness (m)", "ρH∞", "ρV∞", "λ∞", "IP model",
        "H spectrum", "V spectrum", "μr", "Status", "Actions",
    ]

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self._layers: list[EarthLayer] = []
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        toolbar = QVBoxLayout()
        primary = QHBoxLayout()
        secondary = QHBoxLayout()
        self.uniform_btn = secondary_button("Uniform half-space")
        self.add_btn = QPushButton("Add finite layer")
        self.edit_btn = QPushButton("Edit layer")
        self.copy_btn = secondary_button("Duplicate layer")
        self.iso_btn = secondary_button("Copy H→V")
        self.same_btn = secondary_button("Match properties")
        self.up_btn = secondary_button("Move up")
        self.down_btn = secondary_button("Move down")
        self.delete_btn = danger_button("Delete")
        for button in [self.uniform_btn, self.add_btn, self.edit_btn, self.copy_btn]:
            primary.addWidget(button)
        primary.addStretch()
        for button in [self.iso_btn, self.same_btn, self.up_btn, self.down_btn, self.delete_btn]:
            secondary.addWidget(button)
        secondary.addStretch()
        toolbar.addLayout(primary)
        toolbar.addLayout(secondary)
        root.addLayout(toolbar)

        self.table = QTableWidget(0, len(self.HEADERS))
        self.table.setHorizontalHeaderLabels(self.HEADERS)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.Stretch)
        header.setSectionResizeMode(7, QHeaderView.Stretch)
        header.setSectionResizeMode(8, QHeaderView.Stretch)
        self.table.setMinimumHeight(310)
        root.addWidget(self.table, 1)

        self.uniform_btn.clicked.connect(self.reset_uniform)
        self.add_btn.clicked.connect(self.add_finite_layer)
        self.edit_btn.clicked.connect(self.edit_selected)
        self.copy_btn.clicked.connect(self.copy_selected)
        self.iso_btn.clicked.connect(self.set_selected_isotropic)
        self.same_btn.clicked.connect(self.make_all_same)
        self.up_btn.clicked.connect(lambda: self.move_selected(-1))
        self.down_btn.clicked.connect(lambda: self.move_selected(1))
        self.delete_btn.clicked.connect(self.delete_selected)
        self.table.cellDoubleClicked.connect(lambda row, _col: self.edit_row(row))
        self.table.currentCellChanged.connect(lambda *_: self._update_button_state())

        default = IPModel("COLE_COLE", 0.01, legacy=(0.1, 0.1, 0.7, 1.0)).finalize()
        self.set_layers([EarthLayer("Uniform half-space", None, default, 1.0, copy.deepcopy(default))])

    @staticmethod
    def _item(value, align=Qt.AlignCenter) -> QTableWidgetItem:
        item = QTableWidgetItem(str(value))
        item.setTextAlignment(align)
        item.setFlags(item.flags() & ~Qt.ItemIsEditable)
        return item

    def selected_row(self) -> int:
        rows = self.table.selectionModel().selectedRows() if self.table.selectionModel() else []
        return rows[0].row() if rows else self.table.currentRow()

    def _select_row(self, row: int) -> None:
        if 0 <= row < len(self._layers):
            self.table.setCurrentCell(row, 0)
            self.table.selectRow(row)
            self.table.scrollToItem(self.table.item(row, 0))

    def set_layers(self, layers: list[EarthLayer]) -> None:
        self._layers = [copy.deepcopy(layer).finalize() for layer in layers]
        self._refresh(0)

    def layers(self) -> list[EarthLayer]:
        if not self._layers:
            raise ValueError("At least one earth layer is required")
        return [copy.deepcopy(layer).finalize() for layer in self._layers]

    def _refresh(self, selected: int | None = None) -> None:
        if selected is None:
            selected = self.selected_row()
        self.table.setRowCount(len(self._layers))
        for row, layer in enumerate(self._layers):
            layer.finalize()
            h = layer.model
            v = layer.vertical_model
            thickness = "∞" if layer.thickness_m is None else f"{layer.thickness_m:.8g}"
            values = [
                row + 1, layer.name, thickness, f"{1/h.sigma_inf:.8g}",
                f"{1/v.sigma_inf:.8g}", f"{layer.high_frequency_anisotropy:.6g}",
                h.kind, model_brief(h), model_brief(v), f"{layer.mu_r:.6g}",
                "Isotropic" if layer.is_electrically_isotropic else "VTI anisotropic",
            ]
            for col, value in enumerate(values):
                self.table.setItem(row, col, self._item(value, Qt.AlignLeft | Qt.AlignVCenter if col in {1,7,8} else Qt.AlignCenter))
            edit = QPushButton("Edit…")
            edit.clicked.connect(lambda _checked=False, r=row: self.edit_row(r))
            self.table.setCellWidget(row, 11, edit)
            self.table.setRowHeight(row, 42)
        if self._layers:
            self._select_row(min(max(int(selected or 0), 0), len(self._layers)-1))
        self._update_button_state()
        self.changed.emit()

    def edit_selected(self) -> None:
        row = self.selected_row()
        if row < 0:
            QMessageBox.information(self, "Select", "Select the layer to edit.")
            return
        self.edit_row(row)

    def edit_row(self, row: int) -> None:
        if not 0 <= row < len(self._layers):
            return
        dialog = VtiLayerEditorDialog(
            self._layers[row], row == len(self._layers)-1, self
        )
        if dialog.exec() == QDialog.Accepted:
            self._layers[row] = dialog.result_layer()
            self._refresh(row)
            self.message.emit(f"Layer or row {row+1} layer parameters saved")

    def reset_uniform(self) -> None:
        row = self.selected_row()
        template = copy.deepcopy(self._layers[row if row >= 0 else 0])
        template.name = "Uniform half-space"
        template.thickness_m = None
        template.make_isotropic_from_horizontal()
        self._layers = [template]
        self._refresh(0)
        self.message.emit("Reset to isotropic uniform half-space.")

    def add_finite_layer(self) -> None:
        row = self.selected_row()
        template = copy.deepcopy(self._layers[row if row >= 0 else -1])
        template.name = f"Layer {len(self._layers)}"
        template.thickness_m = 100.0
        dialog = VtiLayerEditorDialog(template, False, self)
        if dialog.exec() != QDialog.Accepted:
            return
        insert_at = len(self._layers)-1 if row < 0 or row >= len(self._layers)-1 else row+1
        self._layers.insert(insert_at, dialog.result_layer())
        self._refresh(insert_at)
        self.message.emit(f"Added layer {insert_at+1}")

    def copy_selected(self) -> None:
        row = self.selected_row()
        if row < 0:
            QMessageBox.information(self, "Select", "Select a layer to duplicate.")
            return
        clone = copy.deepcopy(self._layers[row])
        clone.name += " copy"
        if clone.thickness_m is None:
            clone.thickness_m = 100.0
            insert_at = len(self._layers)-1
        else:
            insert_at = row+1
        self._layers.insert(insert_at, clone)
        self._refresh(insert_at)
        self.message.emit("Layer duplicated")

    def set_selected_isotropic(self) -> None:
        row = self.selected_row()
        if row < 0:
            QMessageBox.information(self, "Select", "Select a layer.")
            return
        self._layers[row].make_isotropic_from_horizontal()
        self._refresh(row)
        self.message.emit(f"Layer or row {row+1} set to H=V")

    def make_all_same(self) -> None:
        row = self.selected_row()
        if row < 0:
            QMessageBox.information(self, "Select", "Select a template layer.")
            return
        template = copy.deepcopy(self._layers[row])
        for layer in self._layers:
            layer.model = copy.deepcopy(template.model)
            layer.vertical_model = copy.deepcopy(template.vertical_model)
            layer.mu_r = template.mu_r
            layer.finalize()
        self._refresh(row)
        self.message.emit("All layers now share H/V properties; thicknesses unchanged.")

    def delete_selected(self) -> None:
        row = self.selected_row()
        if row < 0:
            QMessageBox.information(self, "Select", "Select a finite layer.")
            return
        if len(self._layers) == 1:
            QMessageBox.information(self, "Cannot delete", "Keep at least one half-space.")
            return
        if row == len(self._layers)-1:
            QMessageBox.information(self, "Cannot delete", "The final half-space cannot be removed.")
            return
        del self._layers[row]
        self._refresh(min(row, len(self._layers)-1))
        self.message.emit("Layer deleted")

    def move_selected(self, delta: int) -> None:
        row = self.selected_row()
        if row < 0:
            QMessageBox.information(self, "Select", "Select a finite layer.")
            return
        target = row + delta
        if row == len(self._layers)-1:
            QMessageBox.information(self, "Cannot move", "The half-space must remain last.")
            return
        if target < 0 or target >= len(self._layers)-1:
            QMessageBox.information(self, "Cannot move", "Cannot move past the surface or the half-space.")
            return
        self._layers[row], self._layers[target] = self._layers[target], self._layers[row]
        self._refresh(target)
        self.message.emit("Layer order updated")

    def _update_button_state(self) -> None:
        row = self.selected_row()
        count = len(self._layers)
        selected = 0 <= row < count
        finite = selected and row < count-1
        self.edit_btn.setEnabled(selected)
        self.copy_btn.setEnabled(selected)
        self.iso_btn.setEnabled(selected)
        self.same_btn.setEnabled(selected)
        self.delete_btn.setEnabled(finite and count > 1)
        self.up_btn.setEnabled(finite and row > 0)
        self.down_btn.setEnabled(finite and row < count-2)


class SolverWorker(QObject):
    progress = Signal(int, str)
    finished = Signal(object)
    failed = Signal(str)

    def __init__(self, config: SimulationConfig):
        super().__init__()
        self.config = config
        self._cancel = False

    @Slot()
    def run(self):
        try:
            result = solve_stepoff(self.config, self.progress.emit, lambda: self._cancel)
            self.finished.emit(result)
        except Exception:
            self.failed.emit(traceback.format_exc())

    @Slot()
    def cancel(self):
        self._cancel = True


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_TITLE)
        screen = QApplication.primaryScreen()
        bounds = screen.availableGeometry() if screen is not None else None
        if bounds is not None:
            self.resize(min(1500, max(900, int(bounds.width() * 0.92))),
                        min(920, max(600, int(bounds.height() * 0.90))))
        else:
            self.resize(1360, 820)
        self.setMinimumSize(900, 600)
        self.settings = QSettings("GeophysicalStudio", "LongWireIP")
        self.theme_key = self.settings.value("theme", "vscode_dark_modern")
        if self.theme_key not in THEMES:
            self.theme_key = "vscode_dark_modern"
        self.times_s = np.array([], dtype=float)
        self.time_file = ""
        self.result: SimulationResult | None = None
        self.worker: SolverWorker | None = None
        self.thread: QThread | None = None
        self.compare_data: tuple[np.ndarray, np.ndarray] | None = None
        self._build_menu()
        self._build_ui()
        self._set_default_receivers()
        if Path(self.time_path.text()).is_file():
            self.load_times()
        self._refresh_layer_preview()
        self._apply_theme()
        self._apply_font_size()

    def _build_menu(self) -> None:
        file_menu = self.menuBar().addMenu("File")
        save_action = QAction("Save configuration…", self)
        load_action = QAction("Open configuration…", self)
        export_action = QAction("Export results…", self)
        save_action.triggered.connect(self.save_configuration)
        load_action.triggered.connect(self.load_configuration)
        export_action.triggered.connect(self.export_results)
        file_menu.addActions([save_action, load_action, export_action])
        model_menu = self.menuBar().addMenu("Model")
        uniform_action = QAction("Reset to uniform half-space", self)
        uniform_action.triggered.connect(self._reset_uniform_from_menu)
        model_menu.addAction(uniform_action)

    def _build_ui(self) -> None:
        central = QWidget()
        root = QVBoxLayout(central)
        root.setContentsMargins(12, 10, 12, 10)
        root.setSpacing(9)

        banner = QFrame()
        banner.setProperty("surface", True)
        banner_layout = QHBoxLayout(banner)
        banner_layout.setContentsMargins(14, 10, 14, 10)
        title_box = QVBoxLayout()
        title = QLabel(APP_TITLE)
        title.setProperty("title", True)
        subtitle = QLabel("Layered earth · VTI · grounded wire source")
        subtitle.setProperty("subtitle", True)
        title_box.addWidget(title)
        title_box.addWidget(subtitle)
        banner_layout.addLayout(title_box, 1)
        self.theme_title = QLabel("Color theme")
        self.theme_title.setProperty("subtitle", True)
        self.theme_combo = QComboBox()
        self.theme_combo.setMinimumWidth(170)
        for key, palette in THEMES.items():
            self.theme_combo.addItem(palette["name"], userData=key)
        self.theme_combo.setCurrentIndex(max(0, self.theme_combo.findData(self.theme_key)))
        self.theme_combo.currentIndexChanged.connect(self._apply_theme)
        self.font_title = QLabel("Text size")
        self.font_title.setProperty("subtitle", True)
        self.font_combo = QComboBox()
        for points in (11, 12, 13, 14):
            self.font_combo.addItem(f"{points} pt", points)
        stored = int(self.settings.value("font_size", 12))
        self.font_combo.setCurrentIndex(max(0, self.font_combo.findData(stored)))
        self.font_combo.currentIndexChanged.connect(self._apply_font_size)
        self.path_badge = QLabel("Active: uniform half-space")
        self.path_badge.setProperty("badge", True)
        banner_layout.addWidget(self.path_badge)
        banner_layout.addSpacing(14)
        banner_layout.addWidget(self.theme_title)
        banner_layout.addWidget(self.theme_combo)
        banner_layout.addSpacing(8)
        banner_layout.addWidget(self.font_title)
        banner_layout.addWidget(self.font_combo)
        root.addWidget(banner)

        horizontal = QSplitter(Qt.Horizontal)
        horizontal.setChildrenCollapsible(False)
        sidebar = QFrame()
        sidebar.setProperty("sidebar", True)
        sidebar.setMinimumWidth(180)
        sidebar.setMaximumWidth(240)
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_layout.setContentsMargins(9, 12, 9, 9)
        nav_title = QLabel("Model Builder")
        nav_title.setProperty("section", True)
        sidebar_layout.addWidget(nav_title)
        self.model_tree = QTreeWidget()
        self.model_tree.setHeaderHidden(True)
        self.model_tree.setIndentation(15)
        self.model_tree.setFocusPolicy(Qt.NoFocus)
        self.model_tree.setExpandsOnDoubleClick(False)
        workflow = [
            ("01  Earth layers", "Anisotropy / IP models"),
            ("02  Sources & receivers", "Finite wire / stations"),
            ("03  Time channels", "Time files / channels"),
            ("04  Numerics", "Filters / quadrature"),
            ("05  Results", "Curves / model / comparison"),
        ]
        self._tree_nodes = []
        for idx, (name, detail) in enumerate(workflow):
            parent = QTreeWidgetItem([name])
            parent.setData(0, Qt.UserRole, idx)
            child = QTreeWidgetItem([detail])
            child.setData(0, Qt.UserRole, idx)
            parent.addChild(child)
            self.model_tree.addTopLevelItem(parent)
            parent.setExpanded(True)
            self._tree_nodes.append(parent)
        self.model_tree.itemClicked.connect(self._tree_selected)
        sidebar_layout.addWidget(self.model_tree, 1)
        sidebar_info = QLabel("1D  ·  VTI / IP")
        sidebar_info.setProperty("subtitle", True)
        sidebar_layout.addWidget(sidebar_info)
        horizontal.addWidget(sidebar)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_layer_tab(), "Earth Layers")
        self.tabs.addTab(self._build_geometry_tab(), "Source & Receivers")
        self.tabs.addTab(self._build_time_tab(), "Time Channels")
        self.tabs.addTab(self._build_numerics_tab(), "Numerical Settings")
        self.tabs.addTab(self._build_results_tab(), "Results")
        self.tabs.currentChanged.connect(self._tab_selected)
        horizontal.addWidget(self.tabs)
        horizontal.setStretchFactor(0, 0)
        horizontal.setStretchFactor(1, 1)
        horizontal.setSizes([205, 1260])
        root.addWidget(horizontal, 1)
        self.model_tree.setCurrentItem(self._tree_nodes[0])

        run_bar = QFrame()
        run_bar.setProperty("surface", True)
        bar = QHBoxLayout(run_bar)
        bar.setContentsMargins(12, 7, 12, 7)
        self.run_btn = QPushButton("Run Simulation")
        self.run_btn.setMinimumWidth(115)
        self.cancel_btn = danger_button("Cancel")
        self.cancel_btn.setEnabled(False)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.status_label = QLabel("Ready")
        self.status_label.setMinimumWidth(110)
        self.run_btn.clicked.connect(self.start_run)
        self.cancel_btn.clicked.connect(self.cancel_run)
        bar.addWidget(self.run_btn)
        bar.addWidget(self.cancel_btn)
        bar.addWidget(self.progress, 1)
        bar.addWidget(self.status_label)
        root.addWidget(run_bar)
        self.setCentralWidget(central)

    def _tree_selected(self, item, _column=0) -> None:
        index = item.data(0, Qt.UserRole)
        if index is not None:
            self.tabs.setCurrentIndex(index)

    def _tab_selected(self, index: int) -> None:
        if 0 <= index < len(self._tree_nodes):
            self.model_tree.setCurrentItem(self._tree_nodes[index])

    def _apply_theme(self, *_args) -> None:
        self.theme_key = self.theme_combo.currentData() or "vscode_dark_modern"
        self.settings.setValue("theme", self.theme_key)
        palette = THEMES[self.theme_key]
        QApplication.instance().setStyleSheet(qss(self.theme_key))
        self.layer_profile.theme_spec = palette
        self._refresh_layer_preview()
        self.refresh_plot()

    def _apply_font_size(self, *_args) -> None:
        points = int(self.font_combo.currentData() or 12)
        self.settings.setValue("font_size", points)
        app = QApplication.instance()
        font = app.font()
        font.setPointSize(points)
        app.setFont(font)
        rcParams["font.size"] = max(11, points - 1)
        rcParams["axes.titlesize"] = points
        rcParams["axes.labelsize"] = max(11, points - 1)
        rcParams["xtick.labelsize"] = max(10, points - 2)
        rcParams["ytick.labelsize"] = max(10, points - 2)
        rcParams["legend.fontsize"] = max(10, points - 2)
        for ax in (self.canvas.response_ax, self.canvas.model_ax):
            ax.title.set_fontsize(points)
            ax.xaxis.label.set_fontsize(max(11, points - 1))
            ax.yaxis.label.set_fontsize(max(11, points - 1))
            ax.tick_params(labelsize=max(10, points - 2))
        self.canvas.draw_idle()

    def _build_layer_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        guide = QFrame()
        guide.setProperty("hint", True)
        guide_layout = QHBoxLayout(guide)
        tip = QLabel(
            "Workflow: add/select a layer → double-click to edit horizontal H and vertical V properties. "
            "The last layer remains a half-space; H=V is isotropic."
        )
        tip.setWordWrap(True)
        self.limit_check_btn = QPushButton("Verify isotropic limit")
        self.limit_check_btn.clicked.connect(self.run_isotropic_regression)
        guide_layout.addWidget(tip, 1)
        guide_layout.addWidget(self.limit_check_btn)
        layout.addWidget(guide)
        splitter = QSplitter(Qt.Horizontal)
        self.layer_table = LayerTable()
        self.layer_profile = LayerProfileCanvas()
        right = QGroupBox("Model preview & validation")
        right_layout = QVBoxLayout(right)
        right_layout.addWidget(self.layer_profile, 1)
        self.layer_summary = QPlainTextEdit()
        self.layer_summary.setReadOnly(True)
        self.layer_summary.setMaximumHeight(190)
        right_layout.addWidget(self.layer_summary)
        self.limit_status = QLabel("Isotropic limit: not tested")
        self.limit_status.setProperty("badge", True)
        right_layout.addWidget(self.limit_status)
        splitter.addWidget(self.layer_table)
        splitter.addWidget(right)
        splitter.setStretchFactor(0, 4)
        splitter.setStretchFactor(1, 2)
        layout.addWidget(splitter, 1)
        self.layer_table.changed.connect(self._refresh_layer_preview)
        self.layer_table.message.connect(self._show_status)
        return page

    def _build_geometry_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        source_box = QGroupBox("Finite grounded wire (x east, y north, z positive downward)")
        grid = QGridLayout(source_box)
        defaults = {"x1": -200.0, "y1": 0.0, "z1": 0.0, "x2": 200.0, "y2": 0.0, "z2": 0.0}
        self.src_fields = {key: SciSpinBox(value) for key, value in defaults.items()}
        positions = [("x1", 0, 0), ("y1", 0, 2), ("z1", 0, 4), ("x2", 1, 0), ("y2", 1, 2), ("z2", 1, 4)]
        for key, row, column in positions:
            grid.addWidget(QLabel(f"{key} (m)"), row, column)
            grid.addWidget(self.src_fields[key], row, column + 1)
        self.current = SciSpinBox(1.0, 1.0e-12, 1.0e12)
        grid.addWidget(QLabel("Pre-shutoff current I0 (A)"), 2, 0)
        grid.addWidget(self.current, 2, 1)
        layout.addWidget(source_box)

        receiver_box = QGroupBox("Point receivers")
        receiver_layout = QVBoxLayout(receiver_box)
        self.rec_table = QTableWidget(0, 6)
        self.rec_table.setHorizontalHeaderLabels(["Name", "x(m)", "y(m)", "z(m)", "Quantity", "Component"])
        self.rec_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.rec_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        receiver_layout.addWidget(self.rec_table)
        actions = QHBoxLayout()
        add = QPushButton("Add receiver")
        duplicate = secondary_button("Duplicate receiver")
        remove = danger_button("Remove receiver")
        add.clicked.connect(self.add_receiver)
        duplicate.clicked.connect(self.duplicate_receiver)
        remove.clicked.connect(self.remove_receivers)
        actions.addWidget(add)
        actions.addWidget(duplicate)
        actions.addWidget(remove)
        actions.addStretch()
        receiver_layout.addLayout(actions)
        layout.addWidget(receiver_box, 1)
        return page

    def _build_time_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        box = QGroupBox("Import time channels")
        grid = QGridLayout(box)
        self.time_path = QLineEdit(str(Path(__file__).resolve().parents[2] / "example_times.txt"))
        browse = QPushButton("Browse…")
        load = secondary_button("Load & validate")
        self.time_column = QSpinBox()
        self.time_column.setRange(1, 100)
        self.time_column.setValue(1)
        self.time_unit = QComboBox()
        self.time_unit.addItems(["s", "ms", "us", "ns"])
        browse.clicked.connect(self.browse_time)
        load.clicked.connect(self.load_times)
        grid.addWidget(QLabel("Time file"), 0, 0)
        grid.addWidget(self.time_path, 0, 1, 1, 4)
        grid.addWidget(browse, 0, 5)
        grid.addWidget(load, 0, 6)
        grid.addWidget(QLabel("Time column"), 1, 0)
        grid.addWidget(self.time_column, 1, 1)
        grid.addWidget(QLabel("Time unit"), 1, 2)
        grid.addWidget(self.time_unit, 1, 3)
        layout.addWidget(box)
        self.time_preview = QPlainTextEdit()
        self.time_preview.setReadOnly(True)
        self.time_preview.setPlaceholderText("Choose a one-column time file, or time.txt with N_CHANNEL / CHANNEL_MODE.")
        layout.addWidget(self.time_preview, 1)
        return page

    def _build_numerics_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        preset_box = QGroupBox("Precision presets")
        preset_layout = QHBoxLayout(preset_box)
        self.precision_preset = QComboBox()
        self.precision_preset.addItems(["High precision (recommended)", "Fine baseline", "Fast preview", "Independent QWE check", "Custom"])
        apply_preset = QPushButton("Apply preset")
        apply_preset.clicked.connect(self.apply_precision_preset)
        preset_layout.addWidget(QLabel("Preset"))
        preset_layout.addWidget(self.precision_preset)
        preset_layout.addWidget(apply_preset)
        preset_layout.addStretch()
        layout.addWidget(preset_box)

        box = QGroupBox("Filters, source quadrature & interface settings")
        form = QFormLayout(box)
        self.srcpts = QSpinBox()
        self.srcpts.setRange(3, 999)
        self.srcpts.setSingleStep(2)
        self.srcpts.setValue(81)
        self.epsilon = SciSpinBox(1.0e-5, 1.0e-12, 1.0)
        self.air_sigma = SciSpinBox(1.0e-8, 1.0e-14, 1.0)
        self.hmethod = QComboBox()
        self.hmethod.addItems(["dlf", "qwe"])
        self.hfilter = QComboBox()
        self.hfilter.addItems(["key_201_2009", "key_401_2009"])
        self.ffilter = QComboBox()
        self.ffilter.addItems(["key_601_2009", "key_201_2012"])
        self.hppd = SciSpinBox(0.0, -1.0, 100.0)
        self.fppd = SciSpinBox(-1.0, -1.0, 100.0)
        form.addRow("Wire integration points", self.srcpts)
        form.addRow("Below-interface offset ε (m)", self.epsilon)
        form.addRow("Air conductivity (S/m)", self.air_sigma)
        form.addRow("Hankel method", self.hmethod)
        form.addRow("Hankel filter", self.hfilter)
        form.addRow("Fourier filter", self.ffilter)
        form.addRow("Hankel pts/dec", self.hppd)
        form.addRow("Fourier pts/dec", self.fppd)
        layout.addWidget(box)
        note = QLabel(
            "The uniform and layered solvers use consistent filters, wire integration, and time transformations. "
            "For accuracy checks, use Key-201 Hankel and Key-601 Fourier with QWE spot checks."
        )
        note.setWordWrap(True)
        note.setProperty("subtitle", True)
        layout.addWidget(note)
        layout.addStretch()
        return page

    def _build_results_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        controls = QHBoxLayout()
        self.result_receiver = QComboBox()
        self.result_receiver.currentIndexChanged.connect(self.refresh_plot)
        compare = secondary_button("Import 3D reference")
        export = QPushButton("Export results")
        compare.clicked.connect(self.load_3d_compare)
        export.clicked.connect(self.export_results)
        self.export_dir = QLineEdit(str(Path.cwd() / "output"))
        browse = secondary_button("Output directory…")
        browse.clicked.connect(self.browse_output)
        controls.addWidget(QLabel("Receiver"))
        controls.addWidget(self.result_receiver)
        controls.addWidget(compare)
        controls.addWidget(QLabel("Output"))
        controls.addWidget(self.export_dir, 1)
        controls.addWidget(browse)
        controls.addWidget(export)
        layout.addLayout(controls)
        splitter = QSplitter(Qt.Horizontal)
        self.canvas = ResponseCanvas()
        self.result_text = QPlainTextEdit()
        self.result_text.setReadOnly(True)
        splitter.addWidget(self.canvas)
        splitter.addWidget(self.result_text)
        splitter.setStretchFactor(0, 4)
        splitter.setStretchFactor(1, 1)
        layout.addWidget(splitter, 1)
        return page

    def _show_status(self, text: str) -> None:
        self.status_label.setText(text)

    def _refresh_layer_preview(self) -> None:
        try:
            layers = self.layer_table.layers()
            dummy = SimulationConfig(
                layers=copy.deepcopy(layers),
                source=Source(),
                receivers=[Receiver("diagnostic", 1.0, 0.0, 0.0)],
                times_s=[1.0e-5],
                numerics=Numerics(),
            )
            summary = anisotropy_summary(dummy)
            if summary["original_uniform_path"]:
                message = "Original uniform half-space solver"
            elif summary["isotropic_limit"]:
                message = "Layered isotropic solver"
            elif summary["collapsed_layer_count"] == 1:
                message = "VTI half-space solver"
            else:
                message = "Layered VTI semi-analytical solver"
            self.path_badge.setText(f"Active: {message}")
            self.layer_profile.draw_layers(layers, message)
            lines = [
                f"Input layer count: {summary['layer_count']}",
                f"Collapsed VTI layers: {summary['collapsed_layer_count']}",
                f"Anisotropic layers: {summary['anisotropic_layers'] or 'None'}",
                f"Solver path: {message}",
                "",
            ]
            depth = 0.0
            for index, layer in enumerate(layers, 1):
                bottom = "∞" if layer.thickness_m is None else f"{depth + layer.thickness_m:.6g} m"
                lines.append(
                    f"{index}. {layer.name} | base {bottom} | {layer.model.kind} | "
                    f"ρH∞={1/layer.model.sigma_inf:.6g} | "
                    f"ρV∞={1/layer.vertical_model.sigma_inf:.6g} | "
                    f"λ∞={layer.high_frequency_anisotropy:.6g}"
                )
                if layer.thickness_m is not None:
                    depth += layer.thickness_m
            lines += [
                "",
                "Validation domain: σx=σy=σH, σz=σV; the VTI axis is normal to layering.",
                "Triaxial or rotated anisotropy lies outside the 1D layered solver.",
            ]
            self.layer_summary.setPlainText("\n".join(lines))
        except Exception as exc:
            self.path_badge.setText("Active: layer parameters need correction")
            self.layer_profile.draw_layers([], str(exc))
            self.layer_summary.setPlainText(f"Invalid layer parameters: {exc}")

    def _reset_uniform_from_menu(self) -> None:
        self.tabs.setCurrentIndex(0)
        self.layer_table.reset_uniform()

    def _set_default_receivers(self) -> None:
        self.add_receiver("R1_Ex", 400.0, 100.0, 0.0, "E", "X")
        self.add_receiver("R2_dBzdt", 400.0, 100.0, 0.0, "DBDT", "Z")

    def add_receiver(
        self,
        name: str | bool = "",
        x: float = 400.0,
        y: float = 100.0,
        z: float = 0.0,
        quantity: str = "E",
        component: str = "X",
    ) -> None:
        if isinstance(name, bool):
            name = ""
        row = self.rec_table.rowCount()
        self.rec_table.insertRow(row)
        values = [str(name or f"R{row + 1}"), f"{x:.12g}", f"{y:.12g}", f"{z:.12g}"]
        for column, value in enumerate(values):
            item = QTableWidgetItem(value)
            item.setTextAlignment(Qt.AlignCenter)
            self.rec_table.setItem(row, column, item)
        qcombo = QComboBox()
        qcombo.addItems(["E", "H", "B", "DBDT"])
        qcombo.setCurrentText(quantity)
        ccombo = QComboBox()
        ccombo.addItems(["X", "Y", "Z"])
        ccombo.setCurrentText(component)
        self.rec_table.setCellWidget(row, 4, qcombo)
        self.rec_table.setCellWidget(row, 5, ccombo)
        self.rec_table.selectRow(row)

    def duplicate_receiver(self) -> None:
        row = self.rec_table.currentRow()
        if row < 0:
            QMessageBox.information(self, "Select", "Select a receiver.")
            return
        try:
            name = self.rec_table.item(row, 0).text() + "_copy"
            xyz = [float(self.rec_table.item(row, col).text()) for col in [1, 2, 3]]
            quantity = self.rec_table.cellWidget(row, 4).currentText()
            component = self.rec_table.cellWidget(row, 5).currentText()
            self.add_receiver(name, *xyz, quantity, component)
        except Exception as exc:
            QMessageBox.critical(self, "Copy failed", str(exc))

    def remove_receivers(self) -> None:
        rows = sorted({index.row() for index in self.rec_table.selectedIndexes()}, reverse=True)
        if not rows:
            QMessageBox.information(self, "Select", "Select receivers to remove.")
            return
        for row in rows:
            self.rec_table.removeRow(row)

    def browse_time(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select time file",
            "",
            "Time files (*.txt *.dat *.csv);;All files (*)",
        )
        if path:
            self.time_path.setText(path)
            self.load_times()

    def load_times(self) -> None:
        try:
            result = read_observation_times(
                self.time_path.text(),
                self.time_column.value(),
                self.time_unit.currentText(),
            )
            self.times_s = result.times_s
            self.time_file = result.path
            lines = [
                f"Format: {result.source_format}",
                f"Count: {len(result.times_s)}",
                f"Range: {result.times_s[0]:.12e} — {result.times_s[-1]:.12e} s",
                "",
                "First 30 time channels:",
            ]
            lines += [f"{index + 1:4d}  {value:.16e}" for index, value in enumerate(result.times_s[:30])]
            if len(result.times_s) > 30:
                lines.append("…")
            self.time_preview.setPlainText("\n".join(lines))
            self._show_status("Time channels loaded")
        except Exception as exc:
            QMessageBox.critical(self, "Time file error", str(exc))

    def apply_precision_preset(self) -> None:
        preset = self.precision_preset.currentText()
        if preset == "High precision (recommended)":
            self.srcpts.setValue(81)
            self.hmethod.setCurrentText("dlf")
            self.hfilter.setCurrentText("key_201_2009")
            self.ffilter.setCurrentText("key_601_2009")
            self.hppd.setValue(0.0)
            self.fppd.setValue(-1.0)
        elif preset == "Fine baseline":
            self.srcpts.setValue(121)
            self.hmethod.setCurrentText("dlf")
            self.hfilter.setCurrentText("key_201_2009")
            self.ffilter.setCurrentText("key_601_2009")
            self.hppd.setValue(0.0)
            self.fppd.setValue(-1.0)
        elif preset == "Fast preview":
            self.srcpts.setValue(41)
            self.hmethod.setCurrentText("dlf")
            self.hfilter.setCurrentText("key_201_2009")
            self.ffilter.setCurrentText("key_201_2012")
        elif preset == "Independent QWE check":
            self.srcpts.setValue(81)
            self.hmethod.setCurrentText("qwe")
            self.ffilter.setCurrentText("key_601_2009")
        self._show_status(f"Applied: {preset}")

    def build_config(self, require_times: bool = True) -> SimulationConfig:
        if self.times_s.size == 0 and require_times:
            raise ValueError("Load a time file first")
        layers = self.layer_table.layers()
        source = Source(
            self.src_fields["x1"].value(),
            self.src_fields["y1"].value(),
            self.src_fields["z1"].value(),
            self.src_fields["x2"].value(),
            self.src_fields["y2"].value(),
            self.src_fields["z2"].value(),
            self.current.value(),
        )
        receivers: list[Receiver] = []
        for row in range(self.rec_table.rowCount()):
            items = [self.rec_table.item(row, column) for column in range(4)]
            if any(item is None for item in items):
                raise ValueError(f"ReceiverLayer or row {row + 1} row contains an empty cell")
            name = items[0].text().strip() or f"R{row + 1}"
            xyz = [float(items[column].text()) for column in [1, 2, 3]]
            receivers.append(
                Receiver(
                    name,
                    *xyz,
                    self.rec_table.cellWidget(row, 4).currentText(),
                    self.rec_table.cellWidget(row, 5).currentText(),
                )
            )
        numerics = Numerics(
            source_quadrature_points=self.srcpts.value(),
            interface_epsilon_m=self.epsilon.value(),
            air_conductivity_s_per_m=self.air_sigma.value(),
            hankel_pts_per_dec=self.hppd.value(),
            fourier_pts_per_dec=self.fppd.value(),
            verbosity=0,
            hankel_filter=self.hfilter.currentText(),
            fourier_filter=self.ffilter.currentText(),
            hankel_method=self.hmethod.currentText(),
            qwe_rtol=1.0e-11,
            qwe_atol=1.0e-30,
            qwe_nquad=81,
            qwe_maxint=200,
        )
        return SimulationConfig(
            layers,
            source,
            receivers,
            (self.times_s.tolist() if self.times_s.size else [1.0e-5]),
            numerics,
            self.time_file,
        )

    def run_isotropic_regression(self) -> None:
        try:
            config = self.build_config(require_times=False)
            report = check_isotropic_limit(config)
            if report["status"] == "PASS":
                text = (
                    "PASS: Isotropic limit matches the reference elementwise; "
                    f"max abs error={report['max_absolute']:.3e}, "
                    f"max rel error={report['max_relative']:.3e}."
                )
                self.limit_status.setText(text)
                self.limit_status.setStyleSheet("background:#e7f8ed;color:#166534;border-radius:8px;padding:6px;font-weight:700;")
                QMessageBox.information(self, "Isotropic limit passed", text)
            else:
                text = (
                    "FAIL: Isotropic limit failed; "
                    f"max abs error={report['max_absolute']:.3e}."
                )
                self.limit_status.setText(text)
                self.limit_status.setStyleSheet("background:#feecec;color:#991b1b;border-radius:8px;padding:6px;font-weight:700;")
                QMessageBox.critical(self, "Isotropic limit failed", text)
        except Exception as exc:
            QMessageBox.critical(self, "Verification failed", str(exc))

    def start_run(self) -> None:
        try:
            config = self.build_config()
        except Exception as exc:
            QMessageBox.critical(self, "Invalid input", str(exc))
            return
        self.run_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)
        self.progress.setValue(0)
        self.thread = QThread(self)
        self.worker = SolverWorker(config)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self.on_progress)
        self.worker.finished.connect(self.on_finished)
        self.worker.failed.connect(self.on_failed)
        self.worker.finished.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.thread.finished.connect(self._thread_done)
        self.thread.start()

    def cancel_run(self) -> None:
        if self.worker:
            self.worker.cancel()
            self.status_label.setText("Cancelling after current receiver…")

    @Slot(int, str)
    def on_progress(self, value: int, text: str) -> None:
        self.progress.setValue(value)
        self.status_label.setText(text)

    @Slot(object)
    def on_finished(self, result) -> None:
        self.result = result
        self.compare_data = None
        self.result_receiver.clear()
        self.result_receiver.addItems(result.receiver_names)
        self.status_label.setText(f"Finished in {result.elapsed_s:.3f} s")
        self.tabs.setCurrentIndex(4)
        self.refresh_plot()

    @Slot(str)
    def on_failed(self, text: str) -> None:
        self.status_label.setText("Simulation failed")
        QMessageBox.critical(self, "Simulation failed", text)

    def _thread_done(self) -> None:
        self.run_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        if self.thread:
            self.thread.deleteLater()
        self.thread = None
        self.worker = None

    def refresh_plot(self) -> None:
        response_ax = self.canvas.response_ax
        model_ax = self.canvas.model_ax
        response_ax.clear()
        model_ax.clear()
        if self.result is None:
            style_axes(response_ax, THEMES[self.theme_key])
            style_axes(model_ax, THEMES[self.theme_key])
            self.canvas.draw_idle()
            return
        index = max(0, self.result_receiver.currentIndex())
        times = self.result.times_s
        values = self.result.values[:, index]
        palette = THEMES[self.theme_key]
        plot_signed_log_response(response_ax, times, values,
                                 "1D semi-analytical", palette["plot"],
                                 negative_color=palette["negative"])
        text = [
            f"Receiver: {self.result.receiver_names[index]}",
            f"Units: {self.result.units[index]}",
            f"Solver path: {self.result.metadata.get('execution_path', '-')}",
            f"Elapsed time: {self.result.elapsed_s:.6f} s",
            f"Minimum: {values.min():.12e}",
            f"Maximum: {values.max():.12e}",
        ]
        if self.compare_data is not None:
            time_3d, value_3d = self.compare_data
            if time_3d.shape == times.shape and np.allclose(time_3d, times, rtol=1.0e-8, atol=1.0e-14):
                plot_signed_log_response(response_ax, time_3d, value_3d,
                                         "3D", palette["secondary_plot"],
                                         positive_style=":", negative_style="--",
                                         negative_color=palette["negative"], line_width=1.5)
                comparison = metrics(values, value_3d)
                text += ["", "3D comparison:"] + [f"{key}: {value}" for key, value in comparison.items()]
            else:
                text += ["", "3D time channels differ from 1D; overlay skipped."]
        response_ax.set_xlabel("Time (s)")
        response_ax.set_ylabel(f"Magnitude |response| ({self.result.units[index]})")
        response_ax.set_title("Switch-off response · solid positive / dashed negative")
        response_ax.grid(True, which="both", alpha=0.25)
        if response_ax.lines:
            response_ax.legend(fontsize=10)

        try:
            layers = self.layer_table.layers()
            finite_total = sum(float(x.thickness_m or 0.0) for x in layers[:-1])
            extension = max(100.0, finite_total * 0.35, 50.0)
            depth = 0.0
            for layer_index, layer in enumerate(layers):
                bottom = depth + (layer.thickness_m if layer.thickness_m is not None else extension)
                model_ax.plot(
                    [1.0 / layer.model.sigma_inf] * 2,
                    [depth, bottom],
                    linewidth=4.5,
                    label="ρH∞" if layer_index == 0 else None,
                )
                model_ax.plot(
                    [1.0 / layer.vertical_model.sigma_inf] * 2,
                    [depth, bottom],
                    "--",
                    linewidth=2.5,
                    label="ρV∞" if layer_index == 0 else None,
                )
                if layer.thickness_m is not None:
                    depth = bottom
            model_ax.set_xscale("log")
            model_ax.set_ylim(depth + extension, 0.0)
            model_ax.set_xlabel("High-frequency resistivity (Ω·m)")
            model_ax.set_ylabel("Depth (m)")
            model_ax.set_title("VTI Layer Model")
            model_ax.grid(True, which="both", alpha=0.22)
            model_ax.legend(fontsize=10)
        except Exception:
            pass
        style_axes(response_ax, THEMES[self.theme_key])
        style_axes(model_ax, THEMES[self.theme_key])
        self.result_text.setPlainText("\n".join(text))
        self.canvas.draw_idle()

    def browse_output(self) -> None:
        path = QFileDialog.getExistingDirectory(self, "Choose output directory", self.export_dir.text())
        if path:
            self.export_dir.setText(path)

    def export_results(self) -> None:
        if self.result is None:
            QMessageBox.warning(self, "No results", "Run a simulation first.")
            return
        try:
            output = Path(self.export_dir.text())
            paths = write_results(self.result, output)
            save_config(self.build_config(), output / "simulation_config.json")
            self.canvas.figure.savefig(output / "response_and_model.png", dpi=600, bbox_inches="tight")
            QMessageBox.information(self, "Export complete", f"Wrote {len(paths)} data files plus configuration and plot.")
        except Exception as exc:
            QMessageBox.critical(self, "Export failed", str(exc))

    def load_3d_compare(self) -> None:
        if self.result is None:
            QMessageBox.warning(self, "No 1D result", "Run the 1D simulation first.")
            return
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select 3D result file",
            "",
            "Data files (*.dat *.txt *.csv);;All files (*)",
        )
        if not path:
            return
        try:
            self.compare_data = read_numeric_response(path)
            self.refresh_plot()
        except Exception as exc:
            QMessageBox.critical(self, "Failed to read 3D results", str(exc))

    def save_configuration(self) -> None:
        try:
            config = self.build_config()
        except Exception as exc:
            QMessageBox.critical(self, "Cannot save", str(exc))
            return
        path, _ = QFileDialog.getSaveFileName(self, "Save configuration", "simulation_config.json", "JSON (*.json)")
        if path:
            try:
                save_config(config, path)
                self._show_status("Configuration saved")
            except Exception as exc:
                QMessageBox.critical(self, "Save failed", str(exc))

    def load_configuration(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Load configuration", "", "JSON (*.json)")
        if not path:
            return
        try:
            self.apply_config(load_config(path))
            self._show_status("Configuration loaded")
        except Exception as exc:
            QMessageBox.critical(self, "Load failed", str(exc))

    def apply_config(self, config: SimulationConfig) -> None:
        self.layer_table.set_layers(config.layers)
        source = config.source
        for key in ["x1", "y1", "z1", "x2", "y2", "z2"]:
            self.src_fields[key].setValue(getattr(source, key))
        self.current.setValue(source.current_a)
        self.rec_table.setRowCount(0)
        for receiver in config.receivers:
            self.add_receiver(
                receiver.name,
                receiver.x,
                receiver.y,
                receiver.z,
                receiver.quantity,
                receiver.component,
            )
        numerics = config.numerics
        self.srcpts.setValue(numerics.source_quadrature_points)
        self.epsilon.setValue(numerics.interface_epsilon_m)
        self.air_sigma.setValue(numerics.air_conductivity_s_per_m)
        self.hmethod.setCurrentText(numerics.hankel_method)
        self.hfilter.setCurrentText(numerics.hankel_filter)
        self.ffilter.setCurrentText(numerics.fourier_filter)
        self.hppd.setValue(numerics.hankel_pts_per_dec)
        self.fppd.setValue(numerics.fourier_pts_per_dec)
        self.precision_preset.setCurrentText("Custom")
        self.times_s = np.asarray(config.times_s, dtype=float)
        self.time_file = config.time_file
        self.time_path.setText(config.time_file)
        self.time_preview.setPlainText(
            f"Configuration contains {len(self.times_s)} strictly increasing time channels\n"
            f"Range: {self.times_s[0]:.12e} — {self.times_s[-1]:.12e} s"
        )
        self._refresh_layer_preview()


def run_gui() -> int:
    app = QApplication.instance() or QApplication([])
    configure_fonts(app)
    app.setStyleSheet(APP_QSS)
    window = MainWindow()
    window.show()
    return app.exec()
