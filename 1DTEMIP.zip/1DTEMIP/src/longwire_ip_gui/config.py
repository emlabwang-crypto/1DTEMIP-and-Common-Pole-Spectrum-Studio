"""Layered-earth configuration and JSON I/O."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any
import copy
import json
import math

from .models import GemtipPhase, IPModel, MgemtipPhaseInput


@dataclass(frozen=True)
class Source:
    """Finite electric wire; x east, y north, positive z downward."""

    x1: float = -200.0
    y1: float = 0.0
    z1: float = 0.0
    x2: float = 200.0
    y2: float = 0.0
    z2: float = 0.0
    current_a: float = 1.0


@dataclass(frozen=True)
class Receiver:
    name: str
    x: float
    y: float
    z: float
    quantity: str = "E"  # E, H, B, DBDT
    component: str = "X"  # X, Y, Z


def model_to_input_dict(model: IPModel) -> dict[str, Any]:
    return {
        "kind": model.kind,
        "sigma_inf": model.sigma_inf,
        "legacy": list(model.legacy),
        "gemtip_phases": [asdict(x) for x in model.gemtip_phases],
        "mgemtip_input": [asdict(x) for x in model.mgemtip_input],
    }


def _model_signature(model: IPModel) -> str:
    """Canonical exact-input signature, excluding derived cached quantities."""
    return json.dumps(
        model_to_input_dict(model),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )


@dataclass
class EarthLayer:
    """One horizontal layer with optional vertical IP properties."""

    name: str
    thickness_m: float | None
    model: IPModel
    mu_r: float = 1.0
    vertical_model: IPModel | None = None

    def finalize(self) -> "EarthLayer":
        self.name = str(self.name).strip() or "Layer"
        if self.thickness_m is not None:
            self.thickness_m = float(self.thickness_m)
            if not math.isfinite(self.thickness_m) or self.thickness_m <= 0.0:
                raise ValueError(f"Layer “{self.name}” thickness must be positive")
        self.mu_r = float(self.mu_r)
        if not math.isfinite(self.mu_r) or self.mu_r <= 0.0:
            raise ValueError(f"Layer “{self.name}” relative permeability must be positive")
        self.model.finalize()
        if self.vertical_model is None:
            self.vertical_model = copy.deepcopy(self.model)
        self.vertical_model.finalize()
        if self.model.kind != self.vertical_model.kind:
            raise ValueError(
                f"Layer “{self.name}” H and V must use the same IP model family"
            )
        if self.model.kind == "MGEMTIP" and _model_signature(self.model) != _model_signature(self.vertical_model):
            raise ValueError(
                f"Layer “{self.name}” MGEMTIP requires isotropic spherical media; set V=H"
            )
        return self

    @property
    def horizontal_model(self) -> IPModel:
        return self.model

    @property
    def is_electrically_isotropic(self) -> bool:
        self.finalize()
        return _model_signature(self.model) == _model_signature(self.vertical_model)

    @property
    def high_frequency_anisotropy(self) -> float:
        """Empymod VTI lambda = sqrt(rho_v/rho_h) = sqrt(sigma_h/sigma_v)."""
        self.finalize()
        return math.sqrt(self.model.sigma_inf / self.vertical_model.sigma_inf)

    def make_isotropic_from_horizontal(self) -> None:
        self.vertical_model = copy.deepcopy(self.model)
        self.finalize()

    def metadata(self) -> dict[str, Any]:
        self.finalize()
        return {
            "name": self.name,
            "thickness_m": self.thickness_m,
            "mu_r": self.mu_r,
            "anisotropy_class": "ISOTROPIC" if self.is_electrically_isotropic else "VTI",
            "lambda_inf_sqrt_rhov_over_rhoh": self.high_frequency_anisotropy,
            "horizontal_model": self.model.metadata(),
            "vertical_model": self.vertical_model.metadata(),
                "model": self.model.metadata(),
        }


@dataclass(frozen=True)
class Numerics:
    source_quadrature_points: int = 81
    interface_epsilon_m: float = 1.0e-5
    air_conductivity_s_per_m: float = 1.0e-8
    hankel_pts_per_dec: float = 0.0
    fourier_pts_per_dec: float = -1.0
    verbosity: int = 0
    hankel_filter: str = "key_201_2009"
    fourier_filter: str = "key_601_2009"
    hankel_method: str = "dlf"  # dlf or qwe
    qwe_rtol: float = 1.0e-11
    qwe_atol: float = 1.0e-30
    qwe_nquad: int = 81
    qwe_maxint: int = 200


@dataclass
class SimulationConfig:
    layers: list[EarthLayer]
    source: Source
    receivers: list[Receiver]
    times_s: list[float]
    numerics: Numerics
    time_file: str = ""

    @property
    def model(self) -> IPModel:
        """Backward-compatible horizontal model for one-layer configurations."""
        if len(self.layers) != 1:
            raise AttributeError("Layered models have no single model; use layers")
        return self.layers[0].model

    def finalized_layers(self) -> list[EarthLayer]:
        if not self.layers:
            raise ValueError("At least one earth layer is required")
        for layer in self.layers:
            layer.finalize()
        for index, layer in enumerate(self.layers[:-1], 1):
            if layer.thickness_m is None:
                raise ValueError(f"Layer or row {index} is not last; thickness must not be empty")
        if self.layers[-1].thickness_m is not None:
            raise ValueError("Last layer must have infinite thickness (half-space)")
        return self.layers

    def to_dict(self) -> dict[str, Any]:
        self.finalized_layers()
        out = {
            "format_version": 5,
            "earth_model": {
                "coordinate_system": "x East, y North, positive z downward",
                "anisotropy": "1-D VTI: sigma_x=sigma_y=sigma_H, sigma_z=sigma_V",
                "layers": [layer_to_input_dict(x) for x in self.layers],
            },
            "source": asdict(self.source),
            "receivers": [asdict(x) for x in self.receivers],
            "times_s": list(self.times_s),
            "numerics": asdict(self.numerics),
            "time_file": self.time_file,
        }
        if len(self.layers) == 1 and self.layers[0].is_electrically_isotropic:
            out["model_input"] = model_to_input_dict(self.layers[0].model)
        return out


def model_from_input_dict(data: dict[str, Any]) -> IPModel:
    model = IPModel(
        kind=str(data["kind"]),
        sigma_inf=float(data["sigma_inf"]),
        legacy=tuple(float(x) for x in data.get("legacy", [0, 0, 0, 0])),
    )
    for item in data.get("gemtip_phases", []):
        model.gemtip_phases.append(
            GemtipPhase(
                float(item["fraction"]),
                float(item["tau"]),
                float(item["exponent"]),
                tuple(float(v) for v in item.get("gamma", [1 / 3, 1 / 3, 1 / 3])),
                tuple(float(v) for v in item.get("structural_factor", [1, 1, 1])),
            )
        )
    for item in data.get("mgemtip_input", []):
        model.mgemtip_input.append(
            MgemtipPhaseInput(
                float(item["fraction"]),
                float(item["inclusion_sigma"]),
                float(item["radius"]),
                float(item["surface_factor"]),
            )
        )
    return model.finalize()


def layer_to_input_dict(layer: EarthLayer) -> dict[str, Any]:
    layer.finalize()
    return {
        "name": layer.name,
        "thickness_m": layer.thickness_m,
        "mu_r": layer.mu_r,
        # Legacy horizontal key.
        "model_input": model_to_input_dict(layer.model),
        "horizontal_model_input": model_to_input_dict(layer.model),
        "vertical_model_input": model_to_input_dict(layer.vertical_model),
    }


def layer_from_input_dict(data: dict[str, Any]) -> EarthLayer:
    horizontal_data = (
        data.get("horizontal_model_input")
        or data.get("model_input")
        or data.get("model")
    )
    if horizontal_data is None:
        raise ValueError("Layer configuration missing horizontal/model_input")
    vertical_data = data.get("vertical_model_input") or horizontal_data
    thickness = data.get("thickness_m")
    return EarthLayer(
        name=str(data.get("name", "Layer")),
        thickness_m=None if thickness is None else float(thickness),
        model=model_from_input_dict(horizontal_data),
        mu_r=float(data.get("mu_r", 1.0)),
        vertical_model=model_from_input_dict(vertical_data),
    ).finalize()


def save_config(config: SimulationConfig, path: str | Path) -> None:
    Path(path).write_text(
        json.dumps(config.to_dict(), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def load_config(path: str | Path) -> SimulationConfig:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    earth = data.get("earth_model")
    if earth and earth.get("layers"):
        layers = [layer_from_input_dict(x) for x in earth["layers"]]
    elif data.get("layers"):
        layers = [layer_from_input_dict(x) for x in data["layers"]]
    elif data.get("model_input"):
        model = model_from_input_dict(data["model_input"])
        layers = [EarthLayer("Uniform half-space", None, model, 1.0, copy.deepcopy(model))]
    else:
        raise ValueError("No recognizable earth model in configuration")

    cfg = SimulationConfig(
        layers=layers,
        source=Source(**data["source"]),
        receivers=[Receiver(**x) for x in data["receivers"]],
        times_s=[float(x) for x in data["times_s"]],
        numerics=Numerics(**data["numerics"]),
        time_file=data.get("time_file", ""),
    )
    cfg.finalized_layers()
    return cfg
