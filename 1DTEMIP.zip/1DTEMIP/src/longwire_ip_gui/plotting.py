"""Signed signals on logarithmic magnitude axes.

Negative samples use dashed segments; nonpositive times and zero amplitudes
are excluded without altering the original response arrays or their signs.
"""
from __future__ import annotations

import numpy as np


def plot_signed_log_response(ax, times, values, label, color, *,
                             negative_color=None, positive_style='-',
                             negative_style='--', line_width=1.9):
    time = np.asarray(times, dtype=float).ravel()
    signal = np.asarray(values, dtype=float).ravel()
    if time.shape != signal.shape:
        raise ValueError('Time and response arrays must have the same shape')
    valid = np.isfinite(time) & np.isfinite(signal) & (time > 0) & (signal != 0)
    magnitude = np.abs(signal)
    pos = np.where(valid & (signal > 0), magnitude, np.nan)
    neg = np.where(valid & (signal < 0), magnitude, np.nan)
    result = []
    if np.any(np.isfinite(pos)):
        result += ax.plot(time, pos, linestyle=positive_style, linewidth=line_width,
                          color=color, label=label)
    if np.any(np.isfinite(neg)):
        result += ax.plot(time, neg, linestyle=negative_style, linewidth=line_width,
                          color=negative_color or color, label=f'{label} (−)')
    ax.set_xscale('log')
    ax.set_yscale('log')
    return result
